"""
title:          : withasfile.py
                :
source          : https://www.geeksforgeeks.org/with-statement-in-python/ 
                :
author          : Carlos Molina Jimenez
date            : 7 Jul 2023
version         : 1.0
                : withasfile.py
"""




"""
Files can be manipulated with open, write and close
"""
# 1) without using with statement
file = open("carlos_file.txt", "w")
file.write("hello Delfino!")
file.close()


"""
Files can be manipulated with open, write and close
but should account for exceptions
"""
# 2) without using with statement
file = open("carlos_file.txt", "w")
try:
	file.write("hello simon")
finally:
	file.close()


"""
Files can be manipulated with open and with
statement.
Thus, with statement helps avoiding bugs and 
leaks by ensuring that a resource is properly 
released when the code using the resource is 
completely executed. The with statement is popularly 
used with file streams, as shown above and with 
Locks, sockets, subprocesses and telnets etc.
"""

# using with statement
with open("carlos_file.txt", "w") as file:
	file.write("hello marco !")




"""
To use with statement in user defined objects you 
only need to add the methods 
__enter__() and 
__exit__() 
in the object methods.
""" 
# a simple file writer object
class MessageToFile(object):
      def __init__(self, file_name):
         self.file_name = file_name
	
      def __enter__(self):
          self.file = open(self.file_name,"w")
          return self.file

      def __exit__(self, *args):
          self.file.close()

# using with statement with MessageWriter

with MessageToFile("carlos_file.txt") as myfile:
	myfile.write("hello all, I've the iguana")


print("\n End of with demo!")

