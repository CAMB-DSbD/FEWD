"""
title           : sha256.py
description     : teste python hash256  of a sentence with a
                : nonce included
source          : Mastering Bitcoin, Andreas M. Antonopoulos,
                : O'reilly, Second Edition, Jun 2017, pag219   
                : Also available from:
                : https://github.com/bitcoinbook/bitcoinbook/
                : blob/second_edition/code/hash_example.py
author          : Carlos Molina Jimenez
date            : 6 Jan 2018
version         : 1.0
usage           : 
notes           :
compile and run : % python hsh256.py
python_version  : Python Python 2.7.12
====================================================
"""

# example of iterating a nonce in a hashing algorithm's input

import hashlib
    
text = "I am Satoshi Nakamoto"

# iterate nonce from 0 to 19
for nonce in xrange(20): 
    
    # add the nonce to the end of the text.
    # This nonce is used to vary the output of a
    # cryptographic function. In this case, to vary
    # the SHA256 finger print of the phase.
    input = text + str(nonce) 
          
    # calculate the SHA-256 hash of the input (text+nonce)
    hash = hashlib.sha256(input).hexdigest() 
    
    # show the input and hash result
    print input, '=>',  hash
