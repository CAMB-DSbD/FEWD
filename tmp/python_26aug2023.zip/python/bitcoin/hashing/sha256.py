"""
title           : sha256.py
description     : teste python hash256 
source          : Mastering Bitcoin, Andreas M. Antonopoulos,
                : O'reilly, Second Edition, Jun 2017, pag219   
                : Also available from:
                : https://github.com/bitcoinbook/bitcoinbook/
                : blob/second_edition/ch10.asciidoc
author          : Carlos Molina Jimenez
date            : 6 Jan 2018
version         : 1.0
usage           : 
notes           :
compile and run : % python hsh256.py
python_version  : Python Python 2.7.12
====================================================
"""
import hashlib

print hashlib.sha256("I am Satoshi Nakamoto").hexdigest()

