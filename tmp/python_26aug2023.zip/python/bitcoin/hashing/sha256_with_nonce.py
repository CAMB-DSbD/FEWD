"""
title           : sha256.py
description     : teste python hash256  of a sentence with a
                : nonce included.
                : See pag 230 of the book for a clear explanation of
                : the meaning of the nonce and the game of guessing the
                : fingerprint that is less that the target. They use a
                : game of dice... The player has two dice. Imagine the
                : target is 12, then it is easy to meet the target, all
                : throws but 6 and 6 will do. Imagine the target is 2,
                : now most of the throws will fail to meet the target.
source          : Mastering Bitcoin, Andreas M. Antonopoulos,
                : O'reilly, Second Edition, Jun 2017, pag219   
                : Also available from:
                : https://github.com/bitcoinbook/bitcoinbook/
                : blob/second_edition/code/hash_example.py
author          : Carlos Molina Jimenez
date            : 6 Jan 2018
version         : 1.0
usage           : 
notes           :
compile and run : % python hsh256.py
                : The output produces several fingerprints that start
                : with zero, such as output 13 and 28.
                :
python_version  : Python Python 2.7.12
====================================================
"""

# example of iterating a nonce in a hashing algorithm's input

import hashlib
    
text = "I am Satoshi Nakamoto"

# iterate nonce from 0 to 19
#for nonce in xrange(20): 

# iterate nonce from 0 to 60
for nonce in xrange(59): 
    
    # add the nonce to the end of the text.
    # This nonce is used to vary the output of a
    # cryptographic function. In this case, to vary
    # the SHA256 finger print of the phase.
    input = text + str(nonce) 
          
    # calculate the SHA-256 hash of the input (text+nonce)
    hash = hashlib.sha256(input).hexdigest() 
    
    # show the input and hash result
    print input, '=>',  hash
