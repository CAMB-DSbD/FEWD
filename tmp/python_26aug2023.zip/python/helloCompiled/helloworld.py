#!/usr/bin/env python
"""
title           : hello.py
description     : Demonstration of compilation  
source          :  
author          : Carlos Molina Jimenez
date            : 20 Jun 2023 
version         : 1.0
usage           : 
notes           :
compile         : % python3 -m py_compile helloworld.py 
                : ls
                : __pycache__/	helloworld.py
                :
run             : bash-3.2$ python ./__pycache__/helloworld.cpython-37.pyc
                : This line will be printed: Hello world.
                :
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17)  
                :
                : alternatively, run under interpretation
                : bash-3.2$ python helloworld.py
                : This line will be printed: Hello world.
                : 
====================================================
"""

# Definition of a polite function
import socket
import ssl
hostname = 'www.python.org'
print("This line will be printed: Hello world.")
