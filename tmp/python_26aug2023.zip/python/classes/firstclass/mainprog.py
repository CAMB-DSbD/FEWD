#!/usr/bin/env python
"""
title           : mainprog.py
description     : test the absense of init in a class
source          : Learning Python. Mark Lutz, O'Reilly, 5th Edition
                  pag. 799
author          : Carlos Molina Jimenez
date            :  3 Mar 2017
version         : 1.0
usage           :
notes           :
compile and run : % python mainprog.py 
python_version  : Python 2.7.12  
====================================================
"""
import firstclass

myobj= firstclass()

"""
This does'nt work.
%python mainprog.py
  Traceback (most recent call last):
  File "mainprog.py", line 18, in <module>
  myobj= firstclass()
  TypeError: 'module' object is not callable

  It works only in the Python shell


% python3

Python 3.6.0 (v3.6.0:41df79263a11, Dec 22 2016, 17:23:13) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> class fc:
...     def setdata(self,val):
...         self.val= val
...     def display(self):
...         print(self.val)
... 
>>> 
>>> x= fc()
>>> y= fc()
>>> x.setdata("Simon pere")
>>> x.display()
Simon pere
>>> 
>>> x.setdata("Marco")
>>> x.display()
Marco

"""

