#!/usr/bin/env python
"""
title           : firstclass.py
description     : test the absense of init in a class 
source          : Learning Python. Mark Lutz, O'Reilly, 5th Edition
                  pag. 799 
author          : Carlos Molina Jimenez
date            :  3 Mar 2017 
version         : 1.0
usage           : 
notes           :
compile and run : % python mainprog.py 
python_version  : Python 2.7.12   
====================================================
"""

# Definition of the class. It has three methods 
class firstclass:


   def setdata(self,value):
       self.data= value 

   def display(self):
       print("self.data")


