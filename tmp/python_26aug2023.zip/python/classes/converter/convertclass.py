#!/usr/bin/env python
"""
title           : converter.py
description     : basic class and objects: this class provides the basic
                  operations to convert measurements from
                  one unit into another  
source          : Programming the Raspberry Pi: Getting Started with
                  Python. Simon Monk, Second Edition, Mc Graw Hill, 2016 
                  pag. 68
author          : Carlos Molina Jimenez
date            : 20 Feb 2017 
version         : 1.0
usage           : 
notes           :
compile and run : % python converter.py 
python_version  : Python 2.7.12   
====================================================
"""

# Definition of the class. It has three methods 
class ScaleConverter:

   def __init__(self, fromUnits, toUnits, factor):
      self.fromUnits= fromUnits
      self.toUnits=   toUnits
      self.factor=    factor

   def describe(self):
      return "This convertor converts from " + self.fromUnits + " to " + self.toUnits

   def convert(self, value):
      return self.factor*value


