

"""
title           : initexample.py
description     : 
                :
inspiration     : https://www.geeksforgeeks.org/__init__-in-python/ 
source          :
                :
author          : Carlos Molina Jimenez
date            : 19 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 initexample.PBB.py
                :
python_version  : Python 3.7.4 (v3.7.4:e09359112e, Jul 8 2019)
"""

class Person:
  # init method or constructor
  def __init__(self, name):
      self.name = name
 
  # Sample Method
  def say_hi(self):
      print('Person: Hello, my name is', self.name)
 

class Persona():
  # init method or constructor
  def __init__(self, name):
      self.name = name
 
  # Sample Method
  def say_hi(self):
      print('Persona: Hello, my name is', self.name)


class Personas(object): # I don't understand object
  # init method or constructor
  def __init__(self, name):
      self.name = name
 
  # Sample Method
  def say_hi(self):
      print('Persona: Hello, my name is', self.name)


 
# call Person class
p = Person('marcorosario')
p.say_hi()


# call Persona class
p = Persona('simon')
p.say_hi()


# call Personas class
p = Personas('delfino')
p.say_hi()

