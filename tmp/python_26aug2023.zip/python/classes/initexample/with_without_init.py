

"""
title           : with_without_init.py
description     : Demonstrates the use of the init
                : constructor. 
                :
inspiration     :  Python, Mark Luzt, 5th Edi, p799 
source          :
                :
author          : Carlos Molina Jimenez
date            : 19 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 with_without_init.py
                :
python_version  : Python 3.7.4 (v3.7.4:e09359112e, Jul 8 2019)
"""
class Persona():
  # init method or constructor
  def __init__(self, name):
      self.name = name
      self.addr= "Loma larga"
      print("I'm the init method of Persona class")
 
  def print(self):
      print(self.name)
      print(self.addr)


class Person():
  # init method or constructor
  def setdata(self, name):
      self.name = name
  
  def print(self):
      print(self.name)
 
# call Persona class
p1 = Persona('Simon')
p1.print()

# call Person class
###p2 = Person('Marco') Error
###p2.print()

# call Person class
p2 = Person()  # works OK
#p2.print()    # works OK

# call Person class
p3 = Person()      
p3.setdata("figenia")
p3.print()    

