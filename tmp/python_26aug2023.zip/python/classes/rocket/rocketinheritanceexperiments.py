
"""
title           : rocket.py 
description     : just an example of class with inheritance
source          : http://introtopython.org/classes.html
author          : Carlos Molina Jimenez
date            : 1 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python rocketinheritance.py 
python_version  :     
                :
"""


"""
The __init()__ method sets attributes to their proper values 
when an object is created and before the object is used. 
__init__() method initializes the x and y values of the 
Rocket to 0.

self refers to the current object. It refers to certain attributes 
from any other part of the class. All methods in a class need the 
self object as their first argument, so they can access any attribute 
that is part of the class.
"""
from math import sqrt
from random import randint

class Rocket():
    # Rocket simulates a rocket ship for a game,
    #  or a physics simulation.
   

    def __init__(self, x=0, y=1):
        # Each rocket has an (x,y) position. 
        # Default x=0 and y=1
        self.x = x
        self.y = y
        
    def move_up(self, yincrement=1):
        # Increment the y-position of the rocket by the given
        # amount
        self.y += yincrement

    def xdistance(self, otherrocket):
        # Increment the y-position of the rocket by the given
        # amount
        xd= otherrocket.x  - self.x
        return xd


"""
1) The __init__() function of the new class needs to call 
   the __init__() function of the parent class. 

2) The __init__() function of the new class needs to accept 
   all of the parameters required to build an object from 
   the parent class.
   = These parameters need to be passed to the __init__() 
     function of the parent class. 
   = The super().__init__() function takes care of this:
"""

class SuperShuttle(Rocket): # Rocket is the parent class
    # Shuttle simulates a space shuttle, which is really
    #  just a reusable rocket.
    
    def __init__(self, x=100, y=200, flights_completed=300): 
        super().__init__(x, y)
        self.flights_completed = flights_completed


"""
Pass of arguments to supperclass  by explicitly naming the 
parent class
"""
class Shuttle(Rocket):
    # Shuttle simulates a space shuttle, which is really
    #  just a reusable rocket.
    # Rocket is the parent class and has set
    # init.x= 0 init.y= 1
 
    def __init__(self, x=10, y=20, flights_completed=30): # Shuttle's init 
        # 1) In Shuttle x= 10 and y= 20
        # 2) In Rocket  x=0   and y= 1
        Rocket.__init__(self, x, y)    # Must update parent's init
        # 3) Now in Rocket x= 10 and y= 20, the same as in Shuttle
        # 4) Shuttle can have more local attributes, two in this exam
        self.flights_completed = flights_completed
        self.class_name="Shuttle"
       

"""
Pass of arguments to supperclass  by explicitly naming the 
parent class
"""
class PoorShuttle(Rocket):
    # PoorShuttle simulates a space shuttle, which is really
    #  just a reusable rocket.
    # Rocket is the parent class and has set
    # init.x= 0 init.y= 1
 
    def __init__(self, x=2, y=7, flights_completed=0): # Shuttle's init 
        # 1) Given x= 2 and y= 3
        # 2) In Rocket  x=0   and y= 1
        Rocket.__init__(self, y=99) # update ONLY of some parent's init
        # 3) Now in Rocket x is still x= 0 
        #    but y is now y= 99, 
        #
        # 4) PoorShuttle can have more local attributes, three 
        #    in this exam
        self.flights_completed = flights_completed
        self.class_name="PoorShuttle"
        self.owner="Simonpere"
        self.y=y # This asigment overwrites y=99 in superclass 
                 # so PoorShuttle will operate with attributes
                 # self.y=7 and self.x=0
                 # self.y=99 of Rocket supper class in not used
                 # by PoorShuttle
                 # The given x=2 is not used by PoorShuttle
 
super_shuttle= SuperShuttle()
print("Num flights completed by super_shuttle :", super_shuttle.flights_completed)

print("super_shuttle x:", super_shuttle.x)
print("super_shuttle y:", super_shuttle.y)
super_shuttle.move_up(5)

print("\nAfter super_shuttle.move_up(5)")
print("super_shuttle x:", super_shuttle.x)
print("super_shuttle y:", super_shuttle.y)


shuttle= Shuttle()
print("\n\nClass name:", shuttle.class_name)
print("Num flights completed by shuttle :", shuttle.flights_completed)

print("shuttle x:", shuttle.x)
print("shuttle y:", shuttle.y)
shuttle.move_up(5)

print("\nAfter shuttle.move_up(5)")
print("shuttle x:", shuttle.x)
print("shuttle y:", shuttle.y)


p_shuttle= PoorShuttle()
print("\n\nClass name:", p_shuttle.class_name)
print("Num flights completed by p_shuttle :", p_shuttle.flights_completed)

print("p_shuttle x:", p_shuttle.x)
print("p_shuttle y:", p_shuttle.y)
p_shuttle.move_up(5)

print("\nAfter p_shuttle.move_up(5)")
print("p_shuttle x:", p_shuttle.x)
print("p_shuttle y:", p_shuttle.y)
print("p_shuttle owner:", p_shuttle.owner)


