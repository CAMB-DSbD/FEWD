
"""
title           : rocket.py 
description     : just an example of class
source          : http://introtopython.org/classes.html
author          : Carlos Molina Jimenez
date            : 1 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 rocket.py 
python_version  :     
                :
"""


"""
The __init()__ method sets attributes to their proper values 
when an object is created and before the object is used. 
__init__() method initializes the x and y values of the 
Rocket to 0.

self refers to the current object. It refers to certain attributes 
from any other part of the class. All methods in a class need the 
self object as their first argument, so they can access any attribute 
that is part of the class.
"""


class Rocket():
    # Rocket simulates a rocket ship for a game,
    #  or a physics simulation.
   

    def __init__(self, x=0, y=3):
        # Each rocket has an (x,y) position. 
        # Default x=0 and y=3
        self.x = x
        self.y = y
        
    def move_up(self, yincrement=1):
        # Increment the y-position of the rocket by the given
        # amount
        self.y += yincrement



# Create a Rocket object, and have it start to move up.
my_rocket = Rocket(1,1)

print("the variable my_rocket is a Rocket object from ")
print ("The __main__ program file, stored at a particular memory location: ")
print(my_rocket, "\n")

print("Rocket altitude:", my_rocket.y)

my_rocket.move_up()
print("Rocket altitude:", my_rocket.y)

my_rocket.move_up()
print("Rocket altitude:", my_rocket.y)

my_rocket.move_up(10)
print("Rocket altitude:", my_rocket.y)

