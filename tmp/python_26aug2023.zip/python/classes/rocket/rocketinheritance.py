
"""
title           : rocket.py 
description     : just an example of class with inheritance
source          : http://introtopython.org/classes.html
author          : Carlos Molina Jimenez
date            : 1 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python rocketinheritance.py 
python_version  :     
                :
"""


"""
The __init()__ method sets attributes to their proper values 
when an object is created and before the object is used. 
__init__() method initializes the x and y values of the 
Rocket to 0.

self refers to the current object. It refers to certain attributes 
from any other part of the class. All methods in a class need the 
self object as their first argument, so they can access any attribute 
that is part of the class.
"""
from math import sqrt
from random import randint

class Rocket():
    # Rocket simulates a rocket ship for a game,
    #  or a physics simulation.
   

    def __init__(self, x=0, y=0):
        # Each rocket has an (x,y) position. 
        # Default x=0 and y=3
        self.x = x
        self.y = y
        
    def move_up(self, yincrement=1):
        # Increment the y-position of the rocket by the given
        # amount
        self.y += yincrement

    def xdistance(self, otherrocket):
        # Increment the y-position of the rocket by the given
        # amount
        xd= otherrocket.x  - self.x
        return xd



"""
The __init__() function of the new class needs to call 
the __init__() function of the parent class. 
The __init__() function of the new class needs to accept all 
of the parameters required to build an object from the parent 
class, and these parameters need to be passed to the __init__() 
function of the parent class. 
The super().__init__() function takes care of this:
"""

class SuperShuttle(Rocket):
    # Shuttle simulates a space shuttle, which is really
    #  just a reusable rocket.
    
    def __init__(self, x=0, y=0, flights_completed=0): 
        super().__init__(x, y)
        self.flights_completed = flights_completed


"""
Pass of arguments to supperclass  by explicitly naming the 
parent class
"""
class Shuttle(Rocket):
    # Shuttle simulates a space shuttle, which is really
    #  just a reusable rocket.
    
    def __init__(self, x=0, y=0, flights_completed=0): # Shuttle's init 
        Rocket.__init__(self, x, y)               # Must call parent's init
        self.flights_completed = flights_completed
        self.class_name="Shuttle"
       
 
s_shuttle= SuperShuttle(0,0,randint(0,10))
print("Num of flights completed by shuttle :", s_shuttle.flights_completed)

print("s_shuttle altitude:", s_shuttle.y)
s_shuttle.move_up(5)

print("s_shuttle altitude:", s_shuttle.y)



shuttle= Shuttle(0,0,randint(0,5))

print("shuttle's class:", shuttle.class_name)

print("Num of flights completed by shuttle :", shuttle.flights_completed)

print("shuttle altitude:", shuttle.y)
shuttle.move_up(500)
print("shuttle altitude:", shuttle.y)

