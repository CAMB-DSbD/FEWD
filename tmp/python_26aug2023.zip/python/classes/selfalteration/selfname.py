
"""
title           : selfname.py 
description     : Shows how to fetch and change the
                : value of self attributes 
source          : See Learning Python, 5th Edi, Mark Lutz, pg 818
author          : Carlos Molina Jimenez
date            : 25 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 selfname.py 
python_version  :     
                :
"""


class Name():

 def __init__(self):
     print("init method")
     #self.name="nobody" this would declare and include
     # the attribute name in the Name class

 def setname(self, who):
     self.name=  who 
     print("\n setname method: self.name= ", self.name)
     #print("\n setname method: name= ", name) NameError: name 'name' is not defined
     print("\n setname method: who= ", who)



# Create a Rocket object, and have it start to move up.
I1 = Name()

I2 = Name()

I1.setname("marco")
Name().setname("Delfino")
print("\n I1: ", I1.name)


I2.setname("simon")
print("\n I2: ", I2.name)


