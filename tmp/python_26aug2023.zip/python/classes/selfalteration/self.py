
"""
title           : self.py 
description     : Shows how to fetch and change the
                : value of self attributes 
source          : 
author          : Carlos Molina Jimenez
date            : 25 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 self.py 
python_version  :     
                :
"""


class Name():

    def __init__(self):
        # Each rocket has an (x,y) position. 
        # Default x=0 and y=3

        #self.methodname = self.methodname  + " init" 
        # AttributeError: 'Name' object has no attribute 'methodname'

        self.methodname = " init" 
        print("Method name: ", self.methodname)
       
 
    def simon(self):
        self.methodname =  self.methodname + " simon" 
        print("\nMethod name: ", self.methodname)


    def marco(self):
        self.methodname = "marco"
        print("\nMethod name: ", self.methodname)
 
    def delfino(self):
        self.methodname =  self.methodname + " delfino" 
        print("\nMethod name: ", self.methodname)


# Create a Rocket object, and have it start to move up.
name = Name()

name.simon()

name.marco()

name.delfino()


