#!/usr/bin/env python
"""
title           : testconverter.py
description     : basic class and objects: it convertes measurements from
                  one unit into another.
                : The main program testconverter.py is in the current dir whereas
                  the class converterclass.py is a module in ./modules.
                  ./modules is included in the PYTHONPATH variable that I have
                  defines in ~.basrc_profile  
source          : Programming the Raspberry Pi: Getting Started with
                  Python. Simon Monk, Second Edition, Mc Graw Hill, 2016 
                  pag. 68
                : 
                :
author          : Carlos Molina Jimenez
date            : 25 Mar 2017 
version         : 1.1
usage           : 
notes           :
compile and run : % python3 testconverter.py 
python_version  : Python 3.6.0   
====================================================
"""
import convertclass

# Instantiations of the class to test it
myScaleConverter= convertclass.ScaleConverter("yards", "meters", 0.9144)
print (myScaleConverter.describe())
numMeters= myScaleConverter.convert(1)

print("1 yard is equivalent to " + str(numMeters) + " meters")

