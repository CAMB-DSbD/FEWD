#!/usr/bin/env python
"""
title           : converter.py
description     : basic class and objects: it convertes measurements from
                  one unit into another  
source          : Programming the Raspberry Pi: Getting Started with
                  Python. Simon Monk, Second Edition, Mc Graw Hill, 2016 
                  pag. 68
author          : Carlos Molina Jimenez
date            : 30 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3 converter.py 
python_version  : Python 3.6.0   
====================================================
"""
import convertclass

# Instantiations of the class to test it

myScaleConverter= convertclass.ScaleConverter("yards", "meters", 0.9144)

print (myScaleConverter.describe())

numMeters= myScaleConverter.convert(1)

print("1 yard is equivalent to " + str(numMeters) + " meters")

print("\n\n mainprog: " + myScaleConverter.ret_global_var())
