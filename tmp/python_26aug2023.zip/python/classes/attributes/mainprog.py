#!/usr/bin/env python
"""
title           : mainprog.py
description     : testing variable scope and visibility.
                : it needs convertclass.py
source          :
author          : Carlos Molina Jimenez
date            : 3 Mar 2017
version         : 1.0
usage           :
notes           :
compile and run : % python mainprog.py
python_version  : Python 2.7.12
====================================================
"""
import convertclass

# Instantiations of the class to test it

"""
I omit the job parameter in the creation of myScaleConverter
"""
myScaleConverter= convertclass.ScaleConverter("yards", "meters", 0.9144, "Olas init!")

print (myScaleConverter.describe())

numMeters= myScaleConverter.convert(1)

print("1 yard is equivalent to " + str(numMeters) + " meters")

print("\n\n mainprog: " + myScaleConverter.ret_global_var())

print("\n\n mainprog: y= " + str(myScaleConverter.y))

print("\n\n mainprog: factor= " + str(myScaleConverter.factor))

"""
Creation of an instance of ScaleConverter with the inclusion
of the optinal parameter * job *
"""
obj1= convertclass.ScaleConverter("yards", "meters", 0.9144, "Olas init!", "Dr")
print("\n\n mainprog: job= " + obj1.job) # passing Dr by position


obj2=convertclass.ScaleConverter("yards", "meters", 0.9144, "Olas init!", job="Dr")
print("\n\n mainprog: job= " + str(obj2.job) + " pay= " + str(obj2.pay))
                                             # passing Dr by keyword

obj3=convertclass.ScaleConverter("yards", "meters", 0.9144, "Olas init!", job="Dr", pay=100)
print("\n\n mainprog: job= " + str(obj3.job) + " pay= " + str(obj3.pay))

obj4=convertclass.ScaleConverter("yards", "meters", 0.9144, "Olas init!")
print("\n\n mainprog: job= " + str(obj4.job) + " pay= " + str(obj4.pay))

