#!/usr/bin/env python
"""
title           : changeobjectattr.py
description     : basic class and objects: shows how attributes defined
                : in self. change.
                : self.list= list produces two pointers
                : self.intvalue= intvalue   produces two copies of 
                :                intvalue
source          : 
author          : Carlos Molina Jimenez
date            : 22 Jul  2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 changeobjectattr.py 
python_version  : Python 3.6.0   
====================================================
"""

# Definition of the class. It has three methods 
class Playlist:

   def __init__(self, intvalue, lst):
      print("\n")
      self.intvalue= intvalue
      self.lst= lst  

      lst.append(intvalue)
      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])

      for x in range (0,  len(lst)):
          print("lst[", x, "]", lst[x])


   def append2lst(self, ele):
      l= self.lst
      print("\n")
      l.append(ele)  # l is a prt to the same data structure of self.lst
      print("def append2lst:")
      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])
      return l 

   def changeselfvalue(self, newintvalue):
      """
      alteration to self.intvalue changes the state sttribute
      of the object instance
      """
      self.intvalue= newintvalue 
      print("\n")
      self.lst.append(newintvalue)  
      print("def chageselfvalue:")
      print("self.intvalue=", self.intvalue)
      print("value= ", newintvalue)
      
      newintvalue= newintvalue + 100
      """
      alteration to newvalue does not impact self.intvalue
      """
      print("after adding 100 to newintvalue, self.intvalue= ", self.intvalue)
      print("after adding 100 to newintvalue newintvalue= ", newintvalue)
     
      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])


   def displaycurrentinitattr(self):
      print("\n")
      print("def displayinitattr:")
      print("self.intvalue= ", self.intvalue)
      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])


# Instantiations of the class to test it
myPlaylist= Playlist(5,[])
myPlaylist.displaycurrentinitattr()
myPlaylist.changeselfvalue(50)
myPlaylist.displaycurrentinitattr()

