#!/usr/bin/env python
"""
title           : converter.py
description     : basic class and objects: shows how self.list 
                : and other lists are altered by methods.
                : The apend2lst method returns a s pointer
                : to the self.lst attribute of the class.
source          : 
author          : Carlos Molina Jimenez
date            : 22 Jul  2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 converter.py 
python_version  : Python 3.6.0   
====================================================
"""

# Definition of the class. It has three methods 
class Playlist:

   def __init__(self, lst):
      print("\n")
      self.perplaylist=[]  
      self.lst=lst

      for x in range (0,  len(self.perplaylist)):
          print("self.lst[", x, "]", self.perplaylist[x])

      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])


   def append2lst(self, ele):
      l= self.lst
      print("\n")
      l.append(ele)  # l is a prt to the same data structure of self.lst
      print("def append2lst:")
      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])
      return l 

   def append2givenlst(self, l, ele):
      print("\n")
      l.append(ele)  # 
      print("def append2givenlst:")
      for x in range (0,  len(l)):
          print("l[", x, "]", l[x])
      return l 

   def displaycurrentinitattr(self):
      l= self.lst
      print("\n")
      print("def displayinitattr:")
      for x in range (0,  len(self.lst)):
          print("self.lst[", x, "]", self.lst[x])


# Instantiations of the class to test it
myPlaylist= Playlist(["1st ele"])
myPlaylist.append2lst("a")
myPlaylist.displaycurrentinitattr()

l= myPlaylist.append2lst("b")

l.append("z")
print("\n")
print("In main:")
for x in range (0,  len(l)):
    print("l[", x, "]", l[x])

myPlaylist.displaycurrentinitattr()

l.append("zz")

myPlaylist.displaycurrentinitattr()

l1=["one"]
l2= myPlaylist.append2givenlst(l1, "two")
for x in range (0,  len(l1)):
    print("l1[", x, "]", l1[x])

for x in range (0,  len(l2)):
    print("l2[", x, "]", l2[x])


"""

"""
lA=["500"]
lB= myPlaylist.append2givenlst(lA, "501")
lA.append("502")
lB.append("503")



lC= lB # lC is a pointer to the same data structure

print(" ")
for x in range (0,  len(lA)):
    print("lA[", x, "]", lA[x])

print(" ")
for x in range (0,  len(lB)):
    print("lB[", x, "]", lB[x])

print(" ")
for x in range (0,  len(lC)):
    print("lC[", x, "]", lC[x])


lC.append("504")
print("After append 504 to lC")
for x in range (0,  len(lA)):
    print("lA[", x, "]", lA[x])

print(" ")
for x in range (0,  len(lB)):
    print("lB[", x, "]", lB[x])

print(" ")
for x in range (0,  len(lC)):
    print("lC[", x, "]", lC[x])


