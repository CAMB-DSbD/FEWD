#!/usr/bin/env python
"""
title           : converter.py
description     : basic class and objects: shows how self attributes
                  can be accessed and altered by methods
source          : Programming the Raspberry Pi: Getting Started with
                  Python. Simon Monk, Second Edition, Mc Graw Hill, 2016 
                  pag. 68
author          : Carlos Molina Jimenez
date            : 22 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 converter.py 
python_version  : Python 3.6.0   
====================================================
"""

# Definition of the class. It has three methods 
class ScaleConverter:

   def __init__(self, fromUnits, toUnits, factor):
      print("\n")
      self.fromUnits= fromUnits
      self.toUnits=   toUnits
      self.factor=    factor
      print("In def init self.fromUnits= ", self.fromUnits)
      print("In def init self.factor= ",    self.factor)


   def describe(self):
      print("\n")
      return "This convertor converts from " + self.fromUnits + " to " + self.toUnits

   def convert(self, value):
      print("\n")
      print("In def convert self.fromUnits= ", self.fromUnits)
      print("In def convert self.factor= ", self.factor)
      #self.factor= 10
      # This method alters the value of one (self.factor) of the attributes
      self.factor= value 
      return self.factor*value

   def displaycurrentinitattr(self):
      print("\n")
      print("In def displaycurrentinitattr self.fromUnits= ", self.fromUnits)
      print("In def displaycurrentinitattr self.factor= ", self.factor)


# Instantiations of the class to test it
myScaleConverter= ScaleConverter("yards", "meters", 0.9144)
print (myScaleConverter.describe())
numMeters= myScaleConverter.convert(1)

print("1 yard is equivalent to " + str(numMeters) + " meters")

myScaleConverter.displaycurrentinitattr()


