#!/usr/bin/env python
"""
title           : classtesting.py
description     : use of if __name__ == '__main__': for testing a
                : class using code included in the same file
                : Learning Python, Mark Lutz, 5th Edi, p 821  
source          : 
author          : Carlos Molina Jimenez
date            : 3 Mar 2017
version         : 1.0
usage           :
notes           :
compile and run : % python classtesting.py
python_version  : Python 2.7.12

====================================================
"""

path= "silly path"

# Definition of the class. It has three methods 
class ScaleConverter:

   def __init__(self, fromUnits, toUnits, factor, par_for_init_only, job=None, pay=0):
      self.fromUnits= fromUnits
      self.toUnits=   toUnits
      self.factor=    factor  # factor is visible as a class attribute
      self.job=       job     # job can be omitted when an instance of this class is created.
      self.pay=       pay     # pay can be omitted when an instance of this class is created.
                              # job defaults to None. pay defaults to 0
                              # fromUnits, toUnits, factor, etc and self.fromUnits, 
                              # self.toUnits, etc. are just variables that can be used
                              # in anyway such as in assignements.
                              # self.toUnits and toUnits are different vars !
                              # see p818 Learning Python, Mark Lutz 5th Edition.
      self.fromUnits= toUnits       # This is valid but a dangerous bug!!!
      self.fromUnits= "From Hell"   # This is valid but silly   
      self.fromUnits= fromUnits     # Intentional mistake corrected

      print(" __init__: " + par_for_init_only) # par_for_init_only remains a local var within init
                                               # par_for_init_only will not included
                                               # in the instances of ScaleConverter
                                               # self.toUnits is converted into an attribute of
                                               # objs created from this class
      x= 10
      print(" __init__: x is a var defined within init, x= " + str(x))

      self.y= 100
      print(" __init__: y is an attributed added within init, self.y= " + str(self.y))
                        # like factor, y will be included in the instances of ScaleConvertera
                        # and be visible

   def describe(self):
      return "This convertor converts from " + self.fromUnits + " to " + self.toUnits

   def convert(self, value):
      return self.factor*value

   def ret_global_var(self): # Global vars are visible to all methods
#      print(" ret_global_var: x is a var defined within init, x= " + str(x))
               # x is visible only within init

       print("ret_global_var: y is an attributed added within init, self.y= " + str(self.y))
       return path              # and be returned.



#       Class testing now: let us test ScaleConverter
if __name__ == '__main__':
      # Instantiations of the class to test it

      """
      I omit the job parameter in the creation of myScaleConverter
      """
      myScaleConverter=   ScaleConverter("yards", "meters", 0.9144, "Olas init!")

      print (myScaleConverter.describe())

      numMeters= myScaleConverter.convert(1)

      print("1 yard is equivalent to " + str(numMeters) + " meters")

      print("\n\n mainprog: " + myScaleConverter.ret_global_var())

      print("\n\n mainprog: y= " + str(myScaleConverter.y))

      print("\n\n mainprog: factor= " + str(myScaleConverter.factor))

      """
      Creation of an instance of ScaleConverter with the inclusion
      of the optinal parameter * job *
      """
      obj1=   ScaleConverter("yards", "meters", 0.9144, "Olas init!", "Dr")
      print("\n\n mainprog: job= " + obj1.job) # passing Dr by position


      obj2=  ScaleConverter("yards", "meters", 0.9144, "Olas init!", job="Dr")
      print("\n\n mainprog: job= " + str(obj2.job) + " pay= " + str(obj2.pay))
                                                  # passing Dr by keyword

      obj3=  ScaleConverter("yards", "meters", 0.9144, "Olas init!", job="Dr", pay=100)
      print("\n\n mainprog: job= " + str(obj3.job) + " pay= " + str(obj3.pay))

      obj4=  ScaleConverter("yards", "meters", 0.9144, "Olas init!")
      print("\n\n mainprog: job= " + str(obj4.job) + " pay= " + str(obj4.pay))


      
