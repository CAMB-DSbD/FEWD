"""
title           : cli.py
description     : Demonstrates the return of the socket.listen
                : and socket.accept 
                :
source          : https://www.geeksforgeeks.org/
                : python-binding-and-listening-with-sockets/ 
                :
author          : Carlos Molina Jimenez
date            : 1 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 cli.py
                :   It assumes that $ python3 ser_socklisten.py is running
                :   on another shell
python_version  :
                :

"""

import socket
import sys


# specify Host and Port of the server
SERVER_HOST = "127.0.0.1" 
SERVER_PORT = 5789

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

print(f"[+] Connecting to {SERVER_HOST}:{SERVER_PORT}")
soc.connect((SERVER_HOST, SERVER_PORT))
print("[+] Connected.")


