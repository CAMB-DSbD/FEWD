"""
title           : ser_socklisten.py
description     : 
                :
source          : https://www.geeksforgeeks.org/python-binding-and-listening-with-sockets/ 
                :
author          : Carlos Molina Jimenez
date            : 1 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 ser_socklisten.py
python_version  : On another shell run $ py cli.py
                :

"""

import socket
import sys

"""
After that we bound our server to the specified port. 
Passing an empty string means that the server can listen 
to incoming connections from other computers as well. 
If we would have passed 127.0.0.1 then it would have listened 
to only those calls made within the local computer.
"""
# specify Host and Port
HOST = ''  
PORT = 5789


soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
	# With the help of bind() function
	# binding host and port
	soc.bind((HOST, PORT))
	
except socket.error as message:
	
	# if any error occurs then with the
	# help of sys.exit() exit from the program
	print('Bind failed. Error Code : '
		+ str(message[0]) + ' Message '
		+ message[1])
	sys.exit()
	
# print if Socket binding operation completed
print('Socket binding operation completed')

"""
After that we put the server into listen mode. 
9 here means that 9 connections are kept waiting if the 
server is busy and if a 10th socket tries to connect 
then the connection is refused.
"""
soc.listen(9)


"""
Accept connection request when it arrives from
a client.
In this example, the cli.py program sends it
"""
conn, address = soc.accept() 
# address[0]= will contains host, 
# address[1]= will contain port
# print the address of connection
print("Connected with host: " + address[0] + " through port: " + str(address[1]))


