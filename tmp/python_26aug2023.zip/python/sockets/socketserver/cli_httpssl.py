"""
title:          : cli_httpssl.py
                :
source          : https://www.geeksforgeeks.org/ssl-certificate-verification-
                :  python-requests/ 
                : 
author          : Carlos Molina Jimenez
date            : 7 Jul 2023
version         : 1.0
run             : Run: 1) $ python3 serssl.py  in a window shell
                : 2) https://127.0.0.1:4443
                : Safari warns about the lack of certificate
                : "Your connection is not private"
                : "Proceed to 127.0.0.1 (unsafe)"
                : but acceptance of the risk displays
                :
                : Directory listing for /
                : .serssl.py.swp
                : cert.pem
                : cli.py
                : ...
                : ser_ssl.ori.py
                : ser_ssl.py  
                :
                : It shows "Non secure" 
"""

# import requests module
import requests

# Making a get request to server with valid certificate
response = requests.get('https://www.cam.ac.uk:443')
 
# print request object
print("response from  https://www.cam.ac.uk:443", response)
print("\n")


# Making a get request to server with valid certificate
# 443 is the default port for secure connection
# 80  is the default port for unsecure connection
#
response = requests.get('https://www.cam.ac.uk')
 
# print request object
print("response from  https://www.cam.ac.uk", response)
print("\n")
 
"""
The following lines work fine
response = requests.get('https://www.cam.ac.uk', verify = False)
print("response from  https://www.cam.ac.uk under verify = False", response)
print("\n")
"""

# Making a get request
#response = requests.get('https://github.com', verify ='/path / to / certfile')

# Client Side Certificates
# You can also specify a local cert to use as client side 
# certificate, as a single file (containing the private key and 
# the certificate) or as a tuple of both files’ paths: 

#requests.get('https://kennethreitz.org', cert=('/path/client.cert', '/path/client.key'))
# or persistent, If you specify a wrong path or an invalid 
# cert, you’ll get a SSLError:  
# s = requests.Session()
# s.cert = '/path/client.cert'
# server_address = ("127.0.0.1", 4443)

response = requests.get('https://127.0.0.1:4443', verify =False)
print("response from  https://127.0.0.1:4443, verify =False", response)
print("\n")




response = requests.get('https://127.0.0.1:4443', verify ='/Users/carlosmolina/code/python/sockets/socketserver/cert.pem')
print("response from  https://127.0.0.1:4443, verify = ...", response)



# Making a get request to server with invalid certificate
#   response = requests.get('https://expired.badssl.com/')
# print request object
#   print("response from https://expired.badssl.com/ ", response)



"""
1) I created a certicicate in the local dir
/Users/carlosmolina/code/python/sockets/socketserver

bash-3.2$ openssl req -new -x509 -keyout cert.pem -out cert.pem -days 365 -nodes

..+...+......+.+

You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:UK
State or Province Name (full name) [Some-State]:Cambridgeshire
Locality Name (eg, city) []:Cambridge
Organization Name (eg, company) [Internet Widgits Pty Ltd]:University of Cambridge
Organizational Unit Name (eg, section) []:Computer Lab
Common Name (e.g. server FQDN or YOUR name) []:Lab
Email Address []:carlos.molina@cl.cam.ac.uk
bash-3.2$ ls
cert.pem		cli_baseRqHandler.py	ser_baseRqHandler.py	serssl.ori.py
cli.py			cli_streamRqHandler.py	ser_streamRqHandler.py	serssl.py
bash-3.2$ 

"""

