"""
title:          : serssl.py
                :
source          : https://plainenglish.io/blog/python-simple-http-
                : server-with-ssl-certificate-encrypted-traffic-73ffd491a876
                : 
author          : Carlos Molina Jimenez
date            : 7 Jul 2023
version         : 1.0
run             : Run: 1) $ python3 serssl.py  in a window shell
                : 2) https:127.0.0.1:4443
                : Safari warns about the lack of certificate
                : "Your connection is not private"
                : "Proceed to 127.0.0.1 (unsafe)"
                : but acceptance of the risk displays
                : Directory listing for /
                : .serssl.py.swp
                : cert.pem
                : cli.py
                : ...
                : serssl.ori.py
                : serssl.py  
                :
                : It shows "Non secure" 
"""



import http.server, ssl, socketserver

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)

context.load_cert_chain("cert.pem") # PUT YOUR cert.pem HERE

#server_address = ("192.168.43.210", 4443) # CHANGE THIS IP & PORT
server_address = ("127.0.0.1", 4443) # CHANGE THIS IP & PORT

#handler = http.server.SimpleHTTPRequestHandler
handler  = socketserver.BaseRequestHandler

#with socketserver.TCPServer(server_address, handler) as httpd:
#  httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

with socketserver.TCPServer(server_address, handler) as d:
  print("before d.socket") 
  d.socket = context.wrap_socket(d.socket, server_side=True)
  print("before d.serve_forever") 
  d.serve_forever()
  print("after d.serve_forever") 



"""
1) I created a certicicate in the local dir
/Users/carlosmolina/code/python/sockets/socketserver

bash-3.2$ openssl req -new -x509 -keyout cert.pem -out cert.pem -days 365 -nodes

..+...+......+.+

You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:UK
State or Province Name (full name) [Some-State]:Cambridgeshire
Locality Name (eg, city) []:Cambridge
Organization Name (eg, company) [Internet Widgits Pty Ltd]:University of Cambridge
Organizational Unit Name (eg, section) []:Computer Lab
Common Name (e.g. server FQDN or YOUR name) []:Lab
Email Address []:carlos.molina@cl.cam.ac.uk
bash-3.2$ ls
cert.pem		cli_baseRqHandler.py	ser_baseRqHandler.py	serssl.ori.py
cli.py			cli_streamRqHandler.py	ser_streamRqHandler.py	serssl.py
bash-3.2$ 

"""
