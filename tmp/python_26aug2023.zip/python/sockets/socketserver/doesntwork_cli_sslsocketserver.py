"""
https://stackoverflow.com/questions/8582766/adding-ssl-support-to-socketserver
"""

import socket
import pprint

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('localhost', 9999))
sslSocket = socket.ssl(s)
print (repr(sslSocket.server()))
print (repr(sslSocket.issuer()))
sslSocket.write('Hello secure socket\n')
s.close()

