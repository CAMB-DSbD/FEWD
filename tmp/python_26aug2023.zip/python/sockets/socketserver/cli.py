"""
title           : cli.py
description     : A client that connects to a server over a socket
                : to send and receive a string.
                : I tested with both
                : ser_baseRqHandler.py and ser_streamRqHandler.py
                : it worked well.
source          : https://docs.python.org/3/library/socketserver.html#module-socketserver 
                :
author          : Carlos Molina Jimenez
date            : 7 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 cli.py  Hello world
python_version  : Python 3.7.4 (v3.7.4:e09359112e, Jul  8 2019, 14:36:03) 
                :
"""

import socket
import sys

HOST, PORT = "localhost", 9999
data = " ".join(sys.argv[1:])

# Create a socket (SOCK_STREAM means a TCP socket)
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    # Connect to server and send data
    sock.connect((HOST, PORT))
    sock.sendall(bytes(data + "\n", "utf-8"))

    # Receive data from the server and shut down
    received = str(sock.recv(1024), "utf-8")

print("Sent:     {}".format(data))
print("Received: {}".format(received))

