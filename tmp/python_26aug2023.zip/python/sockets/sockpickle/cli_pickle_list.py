"""
title           : ser_pickle_list.py
description     : A client that sends a connection request to a server
                : over a socket and as a response receives a pickle
                : by object that contains a list. 
                : Example of list ['s_A', 's_B', 'c_A']
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 17 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pickle_list.py 
python_version  :     
                :
"""
import socket
import pickle

HEADERSIZE = 10 

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((socket.gethostname(), 1243))

# msg[:headersize] when msg is empty returns b''

while True:
    full_msg = b''
    new_msg = True
    while True:
        msg = s.recv(16)
        if new_msg:
            # take the first HEADERSIZEth elements of the list
            print("new msg len:",msg[:HEADERSIZE])
            msglen = int(msg[:HEADERSIZE])
            new_msg = False

        print(f"full message length: {msglen}")

        full_msg += msg

        print(len(full_msg))

        if len(full_msg)-HEADERSIZE == msglen:
            print("full msg recvd")
            print(full_msg[HEADERSIZE:])
            print(pickle.loads(full_msg[HEADERSIZE:]))
            list=pickle.loads(full_msg[HEADERSIZE:])
            for i in range(0, len(list)):
             print("[", i, "]=", list[i])

            new_msg = True
            full_msg = b""


"""
https://www.tutorialspoint.com/python-extract-specific-keys-from-dictionary
"""
