"""
title           : ser_pickle_list.py
description     : A server that receives a connection request from 
                : a client over a socket and sends back a response
                : that consists of a list serialised as a
                : pickle byte object. 
                : Example of list ['s_A', 's_B', 'c_A']
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 17 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pickle_list.py 
python_version  :     
                :
"""
import socket
import time
import pickle


HEADERSIZE = 10

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((socket.gethostname(), 1243))
s.listen(5)

while True:
    # now our endpoint knows about the OTHER endpoint.
    clientsocket, address = s.accept()
    print(f"Connection from {address} has been established.")

    list = ['s_A', 's_B', 'c_A']
    msg = pickle.dumps(list)
    msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8') + msg
    print(msg)
    # server sends to client
    clientsocket.send(msg)

