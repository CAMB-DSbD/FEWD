"""
title           : ser_pickle_list.py
description     : A server that receives a connection request from 
                : a client over a socket and sends back a response
                : that consists of a list serialised as a
                : pickle byte object. 
                : Example of list ['s_A', 's_B', 'c_A']
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 17 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pickle_list.py 
python_version  :     
                :
"""
import socket
import time
import pickle


HEADERSIZE = 10

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((socket.gethostname(), 1243))
s.listen(5)


# server receives request from client
while True:
    # now our endpoint knows about the OTHER endpoint.
    clisocket, address = s.accept()
    print(f"Connection from {address} has been established.")
    
    full_msg = b''
    new_msg = True
    #while True:
    full_msg_rcvd="NO"
    while full_msg_rcvd=="NO":
        msg = clisocket.recv(16)
        if new_msg:
            # take the first HEADERSIZEth elements of the list
            print("new msg len:",msg[:HEADERSIZE])
            msglen = int(msg[:HEADERSIZE])
            new_msg = False

        print(f"full message length: {msglen}")

        full_msg += msg

        print(len(full_msg))

        if len(full_msg)-HEADERSIZE == msglen:
            print("full msg recvd")
            print(full_msg[HEADERSIZE:])
            print(pickle.loads(full_msg[HEADERSIZE:]))
            list=pickle.loads(full_msg[HEADERSIZE:])
            print("Request from client:")
            for i in range(0, len(list)):
             print("[", i, "]=", list[i])

            new_msg = True
            full_msg = b""
            full_msg_rcvd="YES"

    # server sends response to client
    list = ['s_A', 's_B', 'c_B']
    msg = pickle.dumps(list)
    msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8') + msg
    print(msg)
    # server sends to client
    clisocket.send(msg)
    clisocket.close()

"""
# server receives request
while True:
    # now our endpoint knows about the OTHER endpoint.
    clientsocket, address = s.accept()
    print(f"Connection from {address} has been established.")

    list = ['s_A', 's_B', 'c_A']
    msg = pickle.dumps(list)
    msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8') + msg
    print(msg)
    # server sends to client
    clientsocket.send(msg)
"""
