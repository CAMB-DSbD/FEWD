"""
title           : ser_pbb_nosecchan.py
description     : A server that receives a connection request from 
                : a clients (clia_pbb_nosecchan.py and clia_pbb_nosecchan.py) 
                : over a socket, sends back a response that consists of 
                : a list serialised as a  pickle byte object
                : and loops. 
                : Example of request  ['post', 's_A']
                : Example of response ['s_A', 's_B', 'c_A']
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 20 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pbb_nosecchan.py 
python_version  :     
                :
"""
import socket
import time
import pickle


HEADERSIZE = 10


class Serverpbb():

 def __init__(self):
  self.server= "localhost"
  self.port= 1243
  self.headersize= HEADERSIZE
  self.pbbrecords=[] # list of posted tokens
  
  print("Serverpbb instance has been created")


 def sockconnect(self, ser="localhost", port=1243):
   self.server= ser
   self.port= port
   pbbrecords= self.pbbrecords
 
   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   s.bind((ser, port))
   s.listen(5)


   # server receives request from client
   while True:
    # now our endpoint knows about the OTHER endpoint.
    clisocket, address = s.accept()
    print(f"Connection from {address} has been established.")
    
    full_msg = b''
    new_msg = True
    #while True:
    full_msg_rcvd="NO"
    while full_msg_rcvd=="NO":
        msg = clisocket.recv(16)
        if new_msg:
            # take the first HEADERSIZEth elements of the list
            print("new msg len:",msg[:HEADERSIZE])
            msglen = int(msg[:HEADERSIZE])
            new_msg = False

        print(f"full message length: {msglen}")

        full_msg += msg

        print(len(full_msg))

        if len(full_msg)-HEADERSIZE == msglen:
            print("full msg recvd")
            print(full_msg[HEADERSIZE:])
            print(pickle.loads(full_msg[HEADERSIZE:]))
            list=pickle.loads(full_msg[HEADERSIZE:])
            print("Request from client:")
            for i in range(0, len(list)):
             print("[", i, "]=", list[i])

            new_msg = True
            full_msg = b""
            full_msg_rcvd="YES"
    
                  
    # copy this code to a function 
    if len(list)==2 and list[0] == "post" : 
       print("list[0]=", list[0], "list[1]=", list[1])
       # server sends response to client
       resplist=[list[1], "has been posted"] 
       pbbrecords.append(list[1])
       msg = pickle.dumps(resplist)
       msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8') + msg
       print(msg)
       # server sends to client
       clisocket.send(msg)
       clisocket.close()
   
    # copy this code to a function 
    elif len(list)== 1 and list[0] == "retrieve":
       print("list[0]=", list[0])
       # server sends response to client
       msg = pickle.dumps(pbbrecords)
       msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8') + msg
       print(msg)
       # server sends to client
       clisocket.send(msg)
       clisocket.close()

    # copy this code to a function 
    else: 
       print("ser: Invalid request received")
       # server sends response to client
       resplist = ["Invalid request received"]
       msg = pickle.dumps(resplist)
       msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8') + msg
       print(msg)
       # server sends to client
       clisocket.send(msg)

if __name__ == "__main__":
   serpbb= Serverpbb()
   serpbb.sockconnect()



