"""
title           : ser_pbb_nosecchan.py
description     : A server that receives a connection request from 
                : a clients (clia_pbb_nosecchan.py and clia_pbb_nosecchan.py) 
                : over a socket, sends back a response that consists of 
                : a list serialised as a  pickle byte object
                : and loops. 
                : Example of request  ['post', 's_A']
                : Example of response ['s_A', 's_B', 'c_A']
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 20 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pbb_nosecchan.py -p 1243
                : % python3 ser_pbb_nosecchan.py -p 1245
                : % python3 ser_pbb_nosecchan.py -s "127.0.0.1" -p 1245
                : 
                :
python_version  :     
                :
"""
import socket
import time
import pickle


HEADERSIZE = 10


"""
 Read a serealised message (in pickle format) that 
 contains a list from a socket and return a list.
"""
def recvpicklemsg(clientsocket, headersize):
    # clientsocket: a socket wrapped in SSL context
    #               and already connected to a client
    # headersize:   the size of the header in the msg    
    clisocket= clientsocket
    hsize= headersize

    full_msg = b''
    new_msg = True
    #while True:
    full_msg_rcvd="NO"
    while full_msg_rcvd=="NO":
        msg = clisocket.recv(16)
        if new_msg:
            # take the first hsize th elements of the list
            print("new msg len:",msg[:hsize])
            msglen = int(msg[:hsize])
            new_msg = False

        print(f"full message length: {msglen}")

        full_msg += msg

        print(len(full_msg))

        if len(full_msg) - hsize == msglen:
            print("full msg recvd")
            print(full_msg[hsize:])
            print(pickle.loads(full_msg[hsize:]))
            # recover list sent by client
            list=pickle.loads(full_msg[hsize:])
            print("Request from client:")
            for i in range(0, len(list)):
                print("[", i, "]=", list[i])

            new_msg = True
            full_msg = b""
            full_msg_rcvd="YES"
    return list    



"""
 Given a list that contains a request (post or
 retrieve) and a socket already connected to a 
 client, this function extracts the request,
 composes a response in pickle format with 
 consideration of the hsize (header size) and
 sends it back to the client.
 If the request is post s_A or post c_A, the
 function appends the token to the pbbrecrds.
"""
def sendpicklemsg(clisocket, list, hsize, pbbrecrds): 
  if len(list)==2 and list[0] == "post" : 
     print("list[0]=", list[0], "list[1]=", list[1])
     # server sends response to client
     resplist=[list[1], "has been posted"] 
     pbbrecrds.append(list[1])
     msg = pickle.dumps(resplist)
     msg = bytes(f"{len(msg):<{hsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     clisocket.send(msg)
     clisocket.close()
   
  # copy this code to a function 
  elif len(list)== 1 and list[0] == "retrieve":
     print("list[0]=", list[0])
     # server sends response to client
     msg = pickle.dumps(pbbrecrds)
     msg = bytes(f"{len(msg):<{hsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     clisocket.send(msg)
     clisocket.close()

  # copy this code to a function 
  else: 
     print("ser: Invalid request received")
     # server sends response to client
     resplist = ["Invalid request received"]
     msg = pickle.dumps(resplist)
     msg = bytes(f"{len(msg):<{hsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     clisocket.send(msg)
   

class Serverpbb():

 def __init__(self):
  self.server= "localhost"
  self.port= 1243
  self.headersize= HEADERSIZE
  self.pbbrecords=[] # list of posted tokens
  
  print("Serverpbb instance has been created")


 def sockconnect(self, ser="localhost", port=1243):
   self.server= ser
   self.port= port
   pbbrecrds= self.pbbrecords
   hsize= self.headersize 

   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   s.bind((ser, port))
   print("Server PBB listening at port:", port)
   s.listen(5)

   # server receives request from client
   while True:
    # now our endpoint knows about the OTHER endpoint.
    clisocket, address = s.accept()
    print(f"Connection from {address} has been established.")

    list= recvpicklemsg(clisocket, hsize)

    sendpicklemsg(clisocket, list, hsize, pbbrecrds) 



if __name__ == "__main__":
   import argparse
   parser = argparse.ArgumentParser(description="A server that implements a PBB with no sec chan")
   parser.add_argument("-s", "--server", help="Server implementing the PBB, default is local host", default= "localhost")
   parser.add_argument("-p", "--port", help="Port to use, default is 1243", default=1243)
   args = parser.parse_args()
   server  = args.server
   port    = int(args.port)

   serpbb= Serverpbb()
   serpbb.sockconnect(server, port)

