"""
title           : clib_pbb.py
description     : A client (Bob's) that sends a connection request
                : to a server over a socket and as a response receives 
                : a pickle object that contains a list. 
                : Example of request  ["post", "s_B"]
                : Another example ["retrieve"]
                : Example of response ["s_A", "s_B", "c_A"]
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 18 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pbb.py    on a window shell
                : % python3 clib_pbb.py   on another window shell
python_version  :     
                :
"""
import socket
import pickle

HEADERSIZE = 10 


class ClientPbb():

 def __init__(self):
  self.server= "localhost" 
  self.port= 1243 
  self.headersize= HEADERSIZE 
  print("ClientPbb instance has been created")

 def sockconnect(self, ser="localhost", port=1243):
     self.server= ser
     self.port= port

     s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     #s.connect((socket.gethostname(), 1243))
     s.connect((ser, port))
     return s

 def post(self, socket, token, hsize=HEADERSIZE):
     s= socket
     tkn= token 
     self.headersize= hsize 
     hdsize= hsize

     list = ["post", tkn]
     msg = pickle.dumps(list)
     msg = bytes(f"{len(msg):<{hdsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     s.send(msg)

     full_msg = b''
     new_msg = True
     full_msg_rcvd="NO"
     while full_msg_rcvd=="NO":
         print("post: Client waiting for new msg from server...")
         msg = s.recv(16)
         if new_msg:
             # take the first hdsieze_th elements of the list
             print("new msg len:",msg[:hdsize])
             msglen = int(msg[:hdsize])
             new_msg = False

         print(f"full message length: {msglen}")

         full_msg += msg

         print(len(full_msg))

         if len(full_msg)-hdsize == msglen:
             print("Full msg recvd")
             print(full_msg[hdsize:])
             print(pickle.loads(full_msg[hdsize:]))
             list=pickle.loads(full_msg[hdsize:])
             print("Msg received from server: ")
             for i in range(0, len(list)):
                 print("[", i, "]=", list[i])
             new_msg = True
             full_msg = b""
             full_msg_rcvd="YES"

     #s.close()



 def retrieve(self, socket, hsize=HEADERSIZE):
     s= socket
     self.headersize= hsize 
     hdsize= hsize

     list = ["retrieve"]
     msg = pickle.dumps(list)
     msg = bytes(f"{len(msg):<{hdsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     s.send(msg)
     print("retrieve: Client has sent retrieve to server...")

     full_msg = b''
     new_msg = True
     full_msg_rcvd="NO"
     while full_msg_rcvd=="NO":
         print("retrieve: Client waiting for new msg from server...")
         msg = s.recv(16)
         if new_msg:
             # take the first hdsieze_th elements of the list
             print("new msg len:",msg[:hdsize])
             msglen = int(msg[:hdsize])
             new_msg = False

         print(f"full message length: {msglen}")

         full_msg += msg

         print(len(full_msg))

         if len(full_msg)-hdsize == msglen:
             print("Full msg recvd")
             print(full_msg[hdsize:])
             print(pickle.loads(full_msg[hdsize:]))
             list=pickle.loads(full_msg[hdsize:])
             print("Msg received from server: ")
             for i in range(0, len(list)):
                 print("[", i, "]=", list[i])
             new_msg = True
             full_msg = b""
             full_msg_rcvd="YES"

     #s.close()




if __name__ == "__main__":
   c=ClientPbb()
   #sockconnected= c.sockconnect("127.0.0.1", 1243) works OK
   #c.post(sockconnected, "c_A", 10)  works OK
   sockconnected= c.sockconnect()
   c.post(sockconnected, "c_A", 10)  
   sockconnected.close()

   sockconnected= c.sockconnect()
   c.retrieve(sockconnected)
   sockconnected.close()

