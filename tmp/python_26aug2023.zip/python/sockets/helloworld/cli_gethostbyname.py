"""
title           : cli_gethostname.py
description     : A client that communicates with the 
                : ser_gethostbyname.py 
source          : https://realpython.com/python-sockets/ 
                : 
author          : Carlos Molina Jimenez
date            : 9 Aug 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 cli_gethostbyname.py
                :
python_version  :     
                :
"""
import socket
import time

# echo-client.py

import socket

HOST = "127.0.0.1"  # The server's hostname or IP address
PORT = 65432  # The port used by the server

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    remote_host= s.getpeername()
    print("\naddress and port of remote host that accepted connection rq = ", remote_host) 
    # add: IP address of the host that acceted the connection
    # port: listening port that received and accepyed connection
    #       request
    # The port for sending and receiving messages is different!!!
    
    s.sendall(b"Hello, world")
    data = s.recv(1024)

print(f"Received {data!r}")

