"""
title           : ser_hello127001.py
description     : A server to demonstrate basic socket communication
                : on 127.0.0.1
source          : https://realpython.com/python-sockets/ 
                : 
author          : Carlos Molina Jimenez
date            : 9 Aug 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_hello127001.py
                :
python_version  :     
                :
"""

import socket

# echo-server.py

import socket

#HOST =  "0.0.0.0"   # works fine: any address 
#HOST =  ""          # works fine: any address 
HOST = "127.0.0.1"   # works fine: local host 
PORT = 65432  # Port to listen on (non-privileged ports are > 1023)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    # HOST: The IP address of the host where the server runs
    # PORT: the port number to which the server listens
    #       an accept connections.
    s.bind((HOST, PORT))
    s.listen()
    print("Server listening. Addr= ", HOST, " and port= ", PORT)
    # 
    conn, addr = s.accept() # conn: new socket to be used for communication
    #                         addr: IP add of the remote host 
    # The socket that the server uses to communicate with the 
    # client. It’s distinct from the listening socket that the 
    # server is using to accept new connections
    print("\nServer has accepted connection from remote host with:", addr[0])
    print("                                            and port:", addr[1]) 
    #port is randomly selected by client
    print("port:", addr[1], " was randomly selected by the remote host") 

    print(f"Server has accepted connection from {addr}\n")  # Another way of print 
    with conn:
        while True:
            print(f"Server is connected and in a loop to revc and send data to {addr}")
            peer_add_port= conn.getpeername()
            print("peer_add=", peer_add_port[0])
            print("peer_port=", peer_add_port[1])
            data = conn.recv(1024)
            if not data:
                break
            #conn.sendall(data)
            conn.sendall(b"Client: thanks for sending: " + data)


"""
9 Aug 2023
http://max2.physics.sunysb.edu/itp/computing/doc/python/python-texinfo/socket.html
http://max2.physics.sunysb.edu/itp/computing/doc/python/python-texinfo/socket_object.html#:~:text=The%20return%20value%20is%20a,other%20end%20of%20the%20connection.&text=Bind%20the%20socket%20to%20an,must%20not%20already%20be%20bound
"""
