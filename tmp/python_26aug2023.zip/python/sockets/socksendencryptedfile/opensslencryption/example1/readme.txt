

4 Jun 2023

https://stackoverflow.com/questions/16056135/how-to-use-openssl-to-encrypt-decrypt-files



1) I'm encrypting the file simon.txt which is located in my 
   current folder. Mac Book air, macOS Catalina Version 10.15.7


2) bash-3.2$ openssl version
OpenSSL 3.1.1 30 May 2023 (Library: OpenSSL 3.1.1 30 May 2023)


/Users/carlosmolina/code/python/socketsendencriptedfile/opensslencryption/example1
bash-3.2$ 
bash-3.2$ 
bash-3.2$ ls -l
total 16
-rw-r--r--  1 carlosmolina  staff  106  4 Jul 16:22 readme.txt
-rw-r--r--  1 carlosmolina  staff   17  4 Jul 16:20 simon.txt
bash-3.2$ 


I) Encrypt
bash-3.2$ openssl aes-256-cbc -e -salt -pbkdf2 -iter 10000 -in simon.txt -out simonencrypted.dat
enter AES-256-CBC encryption password: /* I typed delfino */
Verifying - enter AES-256-CBC encryption password:  /* I typed delfino */

bash-3.2$ ls
readme.txt		simon.txt		simonencrypted.dat
bash-3.2$ more simonencrypted.dat
"simonencrypted.dat" may be a binary file.  See it anyway? 


II) Decript
bash-3.2$ openssl aes-256-cbc -d -salt -pbkdf2 -iter 10000 -in simonencrypted.dat -out simonplaintext.txt
enter AES-256-CBC decryption password:  /* I typed delfino */
bash-3.2$ ls
readme.txt		simon.txt		simonencrypted.dat	simonplaintext.txt
bash-3.2$ more simonplaintext.txt
La iguana verde!
bash-3.2$ 


/*
 *****   Used online key    ******************/
 * key= delfino
 */
bash-3.2$ openssl enc -in juan.txt -out juan.enc -e -aes256 -k delfino
*** WARNING : deprecated key derivation used.
Using -iter or -pbkdf2 would be better.


bash-3.2$ openssl enc -in juan.enc -out juandecrypted.txt -d -aes256 -k delfino
*** WARNING : deprecated key derivation used.
Using -iter or -pbkdf2 would be better.


bash-3.2$ more juandecrypted.txt
La iguana prieta@timu!  /*
                         * it worked fine
                         */




