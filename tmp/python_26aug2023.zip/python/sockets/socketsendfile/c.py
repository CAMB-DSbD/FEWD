"""
title           : cl.py
description     : A client that sends a file to a remote server over
                : a socket. 
                : I run the server (sr.py) on the same computer (MacBook Air)
                : but on a different folder.
source          : https://www.thepythoncode.com/code/send-receive-files-using-sockets-python 
                :
author          : Carlos Molina Jimenez
date            : 3 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run :

                : bash-3.2$ pwd
                : /Users/carlosmolina/code/python/socketsendfile
                :
                : bash-3.2$ ls
                : cl.py	 server/ simon.txt 
                :
                : bash-3.2$ python3 cl.py simon.txt 127.0.0.1
                : [+] Connecting to 127.0.0.1:5001
                : [+] Connected.
                : Sending simon.txt: 100% ... 5.00/5.00 [00:00<00:00, 13.8kB/s]
                :
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17) 
"""

"""
If you wish to run the server code on a remote machine and 
not on the local network, then make sure you allow the port 
on your firewall. If it's a VM in the cloud, then make sure 
you allow it via ufw:
$ ufw allow 5001
"""

import socket
import tqdm
import os
import argparse

from socket_files import read_send_file

SEPARATOR = "<SEPARATOR>"
BUFFER_SIZE = 1024 * 4 #4KB

def send_file(filename, host, port):
    # get the file size
    filesize = os.path.getsize(filename)
    # create the client socket
    s = socket.socket()
    print(f"[+] Connecting to {host}:{port}")
    s.connect((host, port))
    print("[+] Connected.")

    # send the filename and filesize
    s.send(f"{filename}{SEPARATOR}{filesize}".encode())

    # start sending the file
    read_send_file(filename, filesize,  BUFFER_SIZE, s)

    """
    progress = tqdm.tqdm(range(filesize), f"Sending {filename}", unit="B", unit_scale=True, unit_divisor=1024)
    with open(filename, "rb") as f:
        while True:
            # read the bytes from the file
            bytes_read = f.read(BUFFER_SIZE)
            if not bytes_read:
                # file transmitting is done
                break
            # we use sendall to assure transimission in 
            # busy networks
            s.sendall(bytes_read)
            # update the progress bar
            progress.update(len(bytes_read))
    """

    # close the socket
    s.close()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Simple File Sender")
    parser.add_argument("file", help="File name to send")
    parser.add_argument("host", help="The host/IP address of the receiver")
    parser.add_argument("-p", "--port", help="Port to use, default is 5001", default=5001)
    args = parser.parse_args()
    filename = args.file
    host = args.host
    port = args.port
    send_file(filename, host, port)
