"""
title           : sr.py
description     : A server that receives a file to a remote client over
                : a socket.
                : I run the client (cl.py) on the same computer (MacBook Air)
                : but on a different folder.
source          : https://www.thepythoncode.com/code/send-receive-files-using-sockets-python
                :
author          : Carlos Molina Jimenez
date            : 3 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : 

                : bash-3.2$ pwd
                : /Users/carlosmolina/code/python/socketsendfile/server
                :
                : bash-3.2$ ls
                : sr.ori.py   sr.py 
                :
                : bash-3.2$ python3 sr.py
                : [*] Listening as 127.0.0.1:5001
                : [+] ('127.0.0.1', 51994) is connected.
                : Receiving simon.txt: 100 ... 20.0/20.0 [00:00<00:00, 4.42kB/s]
                : bash-3.2$ ls
                : simon.txt  sr.ori.py   sr.py
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17)
"""



import socket
import tqdm
import os

# device's IP address
#SERVER_HOST = "0.0.0.0"
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5001

# receive 4096 bytes each time
BUFFER_SIZE = 4096
SEPARATOR = "<SEPARATOR>"

# create the server socket
# TCP socket
s = socket.socket()

# bind the socket to our local address
s.bind((SERVER_HOST, SERVER_PORT))

# enabling our server to accept connections
# 5 here is the number of unaccepted connections that
# the system will allow before refusing new connections
s.listen(5)
print(f"[*] Listening as {SERVER_HOST}:{SERVER_PORT}")

# accept connection if there is any
client_socket, address = s.accept() 

# if below code is executed, that means the sender is connected
print(f"[+] {address} is connected.")

# receive the file infos
# receive using client socket, not server socket
received = client_socket.recv(BUFFER_SIZE).decode()
filename, filesize = received.split(SEPARATOR)


# remove absolute path if there is
filename = os.path.basename(filename)

# convert to integer
filesize = int(filesize)

# start receiving the file from the socket
# and writing to the file stream
progress = tqdm.tqdm(range(filesize), f"Receiving {filename}", unit="B", unit_scale=True, unit_divisor=1024)

with open(filename, "wb") as f:
    while True:
        # read 1024 bytes from the socket (receive)
        bytes_read = client_socket.recv(BUFFER_SIZE)
        if not bytes_read:    
            # nothing is received
            # file transmitting is done
            break
        # write to the file the bytes we just received
        f.write(bytes_read)
        # update the progress bar
        progress.update(len(bytes_read))

# close the client socket
client_socket.close()
# close the server socket
s.close()

