"""
title:          : cli_defl_context.py
                :
source          : https://docs.python.org/3/library/ssl.html#ssl-contexts 
                : 
author          : Carlos Molina Jimenez
date            : 4 Aug 2023
version         : 1.0
                :
run             : % python3 cli_defl_context.py 
                : Didn't work
"""


import socket
import ssl

hostname = "www.python.org"

"""
context = ssl.create_default_context()

with socket.create_connection((hostname, 443)) as sock:
  with context.wrap_socket(sock, server_hostname=hostname) as myssl_sock:
    print(myssl_sock.version())
"""

# PROTOCOL_TLS_CLIENT requires valid cert chain and hostname
context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


context.load_verify_locations('path/to/cabundle.pem')
########### It doesn't work, I need to create the cabundle.pem
##########  5 Aug 2023


with socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0) as sock:
    with context.wrap_socket(sock, server_hostname=hostname) as ssock:
        print(ssock.version())

