"""
title:          : ser_ssl_listen.py
                :
source          : https://docs.python.org/3/library/ssl.html#ssl-contexts 
                : 
author          : Carlos Molina Jimenez
date            : 4 Aug 2023
version         : 1.0
                :
run             : % python3 ser_ssl_listen.py 
                :                   
"""


import socket
import ssl


context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain('/path/to/certchain.pem', '/path/to/private.key')
########### It doesn't work, I need to create the cabundle.pem
##########  5 Aug 2023


with socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0) as sock:
    sock.bind(('127.0.0.1', 8443))
    sock.listen(5)
    with context.wrap_socket(sock, server_side=True) as ssock:
        conn, addr = ssock.accept()






