#!/usr/bin/env python
#title           : memofactorial.py
#description     : An example of memotization. It uses memotization
#                  to compute the factorial of a number. 
#source          : https://stackoverflow.com/questions/1988804
#                  /what-is-memoization-and-how-can-i-use-it-in-python 
#author          : Carlos Molina Jimenez
#date            : 19 Sep 2020  Computer Lab, Univ Cambridge
#version         : 1.0
#notes           : See pg. 387 of  Introduction to Algorithms
#                  Third Edition.   
#python_version  : Python 3.6.0  on MackBook Air 
#
#compile and run : % python3 memofactorial.py 
#                  it outputs the factorial of the given integer 
#==============================================================


factorial_memo = {}
def factorial(k):
    if k < 2: return 1
    if k not in factorial_memo:
        factorial_memo[k] = k * factorial(k-1)
    return factorial_memo[k]


n= int(input("type and integer: "))
fact= factorial(n)
print("factorial of " + str(n) +  " is " + str(fact)) 
print("By-by-by") 


