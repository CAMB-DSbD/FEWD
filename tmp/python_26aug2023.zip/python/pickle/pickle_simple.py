"""
title           : pickleex.py
description     : Test of the use of pickle to transfer a list 
source          : https://itecnote.com/tecnote/python-how-to-send-a-list-
                :  through-tcp-sockets-python/ 
author          : Carlos Molina Jimenez
date            : 11 Jul 2023
version         : 1.0
usage           : 
compile and run :
                : bash-3.2$ python3 pickleex.py
                :
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17) 
"""

import pickle


def list2str2list(byteobject):
   l=pickle.loads(byteobject)
   for i in range(0, len(l)):
     print ("l[",i,"]=",l[i])
   return pickle.dumps(l)

 
list=[0,1,6,8,3] 
#s.send(data)

byteobj= pickle.dumps(list)

#sb=s.encode()
 
byteobjresp=list2str2list(byteobj)
l=pickle.loads(byteobjresp)
for x in range(len(l)):
    print (l[x])






