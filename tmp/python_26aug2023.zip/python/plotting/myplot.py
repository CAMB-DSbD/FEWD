#!/usr/bin/env python
#title           : myplot.py
#description     : This will create a a basic plot with the help of matplotlib.
#source          : Pag 73 of Joel Grus
#author          : Carlos Molina Jimenez
#date            : 7 Sep 2020
#version         : 1.0
#usage           : python myplot.py
#notes           : I installed % install matplotlib
#                " on my MacBook air first.
#python_version  : Python 3.6.0   
#
#compile and run : % python3 myplot.py 
#                  it outputs the plot in a green line
#======================================================


import matplotlib.pyplot as plt

years= [1950, 1960, 1970, 1980, 1990, 2000, 2010]
gdp=   [300.2, 543.3, 1075.9, 2862.5, 5979.6, 10289.7, 14958.3]
plt.plot(years, gdp, color= 'green', marker='o', linestyle= 'solid')

plt.title("Nominal GDP")

plt.ylabel("Billions of $")
plt.show()


