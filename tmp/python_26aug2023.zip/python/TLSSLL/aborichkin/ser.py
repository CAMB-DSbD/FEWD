"""
https://gist.githubusercontent.com/oborichkin/d8d0c7823fd6db3abeb25f69352a5299/raw/9df0ebe8a42728f20d282ee11f448b675f4df708/tls_server.py

"""


import socket
import ssl

HOST = "127.0.0.1"
PORT = 60000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server = ssl.wrap_socket(
    server, server_side=True, keyfile="path/to/keyfile", certfile="path/to/certfile"
)

if __name__ == "__main__":
    server.bind((HOST, PORT))
    server.listen(0)

    while True:
        connection, client_address = server.accept()
        while True:
            data = connection.recv(1024)
            if not data:
                break
            print(f"Received: {data.decode('utf-8')}")

