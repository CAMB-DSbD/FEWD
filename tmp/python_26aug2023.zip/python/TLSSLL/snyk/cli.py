"""
title           : cli.py
description     : This is a basic server that accepts http requests
                : over secure chain 
source          : https://snyk.io/blog/implementing-tls-ssl-python/
                : but it has some errors
                : This example
                : https://anvileight.com/blog/posts/simple-python-http-server/
                :
                : complemented by https://www.geeksforgeeks.org/python-requests-tutorial/
                :
author          : Carlos Molina Jimenez
date            : 27 Jun 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python cli.py
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17) 
====================================================
"""
"""
syntax: requests.get(url, params={key: value}, args)

"""

#import ssl
import requests

print(' Iam cli.py sending a req...')

response=requests.get('https://cam.ac.uk/')
print("Response from cam server: ", response)


#res = requests.get('http://localhost')
res = requests.get('http://localhost:8000')

print('res : ')
print(res)


print('res content: ')
print(res.content)



