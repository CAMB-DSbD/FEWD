"""
title           : ser.py
description     : This is a basic server that accepts http requests
                : over secure chain 
source          : https://snyk.io/blog/implementing-tls-ssl-python/
                : but it has some errors
                : This example
                : https://anvileight.com/blog/posts/simple-python-http-server/
                : complemented
                :
author          : Carlos Molina Jimenez
date            : 27 Jun 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python ser.py
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17) 
====================================================
"""

import http.server
#from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl

httpd = http.server.HTTPServer(('localhost', 8000), http.server.SimpleHTTPRequestHandler)

httpd.socket = ssl.wrap_socket(httpd.socket, certfile='./certificate.pem', server_side=True, ssl_version=ssl.PROTOCOL_TLS)
httpd.socket = ssl.wrap_socket(httpd.socket, certfile='./certificate.pem', keyfile='./key.pem', 
               server_side=True,  ssl_version=ssl.PROTOCOL_TLS)

print(' Iam ser.py and waiting for reqs ...')
httpd.serve_forever()


"""
from http.server import HTTPServer, BaseHTTPRequestHandler


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'Hello, world!')


httpd = HTTPServer(('localhost', 8000), SimpleHTTPRequestHandler)

print(' Iam ser.py and waiting for reqs ...')
httpd.serve_forever()
"""
