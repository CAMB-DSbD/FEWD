"""
title           : ser.py
description     : This is a basic server that accepts http requests
                : over secure chain 
source          : 
                : https://anvileight.com/blog/posts/simple-python-http-server/
                :
author          : Carlos Molina Jimenez
date            : 29 Jun 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python s.py
python_version  : Python3 3.7.4 (default, Oct  8 2019, 14:48:17) 
====================================================
"""
"""
https://docs.python.org/3/library/http.server.html

"""

from http.server import HTTPServer, BaseHTTPRequestHandler


class CarlosSimpleHTTPRequestHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'Hello, mundo!')



httpd = HTTPServer(('localhost', 8000), CarlosSimpleHTTPRequestHandler)

print(' ser.py waiting for reqs, CarlosSimpleHTTPRequestHandler will deal with them  ...')
httpd.serve_forever()
