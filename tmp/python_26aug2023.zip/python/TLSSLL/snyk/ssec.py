"""
title           : ser.py
description     : This is a basic server that accepts http requests
                : over secure chain 
source          : https://snyk.io/blog/implementing-tls-ssl-python/
                : but it has some errors
                : This example
                : https://anvileight.com/blog/posts/simple-python-http-server/
                : complemented
                :
author          : Carlos Molina Jimenez
date            : 27 Jun 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python ser.py
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17) 
====================================================
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl


httpd = HTTPServer(('localhost', 8000), BaseHTTPRequestHandler)

httpd.socket = ssl.wrap_socket (httpd.socket, 
        keyfile="./key.pem", 
        certfile='./certificate.pem', server_side=True)

httpd.serve_forever()
