"""
title           : ser.py
description     : This is a basic server that accepts http requests
                : over secure chain 
source          : 
                : https://stackoverflow.com/questions/67359204/how-to-run-python-with-simplehttprequesthandler 
                :
author          : Carlos Molina Jimenez
date            : 29 Jun 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python s.py
python_version  : Python3 3.7.4 (default, Oct  8 2019, 14:48:17) 
====================================================
"""
"""
https://docs.python.org/3/library/http.server.html

"""

from http.server import HTTPServer, SimpleHTTPRequestHandler


class CarSimpleHTTPRequestHandler(SimpleHTTPRequestHandler):

    def do_GET(self):

        print(self.path)
        
        if self.path == '/':
            #self.path = '/home/furas/test/index.html'
            self.path = './desktop/formdailyactivities/index.html'
            
            print('original  :', self.path)
            print('translated:', self.translate_path(self.path))
            
            try:
                f = open(self.path, 'rb')
            except OSError:
                self.send_error(HTTPStatus.NOT_FOUND, "File not found")
                return None

            ctype = self.guess_type(self.path)
            fs = os.fstat(f.fileno())
            
            self.send_response(200)
            self.send_header("Content-type", ctype)
            self.send_header("Content-Length", str(fs[6]))
            self.send_header("Last-Modified",
                self.date_time_string(fs.st_mtime))
            self.end_headers()            
            
            try:
                self.copyfile(f, self.wfile)
            finally:
                f.close()
                
        else:
            # run normal code
            print('original  :', self.path)
            print('translated:', self.translate_path(self.path))
            super().do_GET()





httpd = HTTPServer(('localhost', 8000), CarSimpleHTTPRequestHandler)

print(' s.py waiting for reqs, CarSimpleHTTPRequestHandler will deal with them  ...')
httpd.serve_forever()
