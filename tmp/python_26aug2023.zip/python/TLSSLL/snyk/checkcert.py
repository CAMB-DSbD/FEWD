#!/usr/bin/env python

"""
title           : checkcert.py
description     : Demonstration of certf check  
source          :  
                : https://snyk.io/blog/implementing-tls-ssl-python/
author          : Carlos Molina Jimenez
date            : 26 Jun 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python checkcert.py 
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17)  
====================================================
"""
import requests
response=requests.get('https://twitter.com/')
print("Response from twitter server: ", response)

response=requests.get('https://cam.ac.uk/')
print("Response from cam server: ", response)

# This two lines fail: 26 Jun 2023
#response=requests.get('https://morello-camb-1.sm.cl.cam.ac.uk')
#print(response)
