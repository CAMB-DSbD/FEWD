"""
https://stackoverflow.com/questions/8582766/adding-ssl-support-to-socketserver


"""

from OpenSSL import SSL
import socket, SocketServer

class SSlSocketServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):

    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        SocketServer.BaseServer.__init__(self, server_address,
            RequestHandlerClass)
        ctx = SSL.Context(SSL.SSLv3_METHOD)
        cert = 'cert.pem'
        key = 'private_key.pem'
        ctx.use_privatekey_file(key)
        ctx.use_certificate_file(cert)
        self.socket = SSL.Connection(ctx, socket.socket(self.address_family,
            self.socket_type))
        if bind_and_activate:
            self.server_bind()
            self.server_activate()
    def shutdown_request(self,request):
        request.shutdown()

class Decoder(SocketServer.StreamRequestHandler):
    def setup(self):
        self.connection = self.request
        self.rfile = socket._fileobject(self.request, "rb", self.rbufsize)
        self.wfile = socket._fileobject(self.request, "wb", self.wbufsize)

    def handle(self):
        try:
            socket1 = self.connection
            str1 = socket1.recv(4096)
            print(str1)
        except Exception, e:
            print ("socket error",e)
def main():
    server = SSlSocketServer(('127.0.0.1', 9999), Decoder)
    server.serve_forever()
if __name__ == '__main__':
    main()
