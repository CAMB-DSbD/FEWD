"""
title           : cli_file_file.py 
description     : A client that establishes a secure chan over ssl
                : with a server to send a file and receive another
                : file as response.
                : I tested it with plain txt, jpeg and encrypted
                : files under 
                : encrypt
                : $ openssl aes-256-cbc -e -salt -pbkdf2 -iter 10000 -in 
                :   cat.jpg -out cat_encrypted.dat
                : decrypt
                : $ openssl aes-256-cbc -d -salt -pbkdf2 -iter 10000 -in 
                : cat_encrypted.dat -out cat_decrypted.jpg
                : 
source          : https://github.com/mikepound/tls-exercises
                : 
author          : Carlos Molina Jimenez
date            : 6 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 cli_file_file.py 
python_version  :     
                :
"""
import socket
import ssl
from pathlib import Path

# five new lines
import tqdm
import os
import argparse

from files2sockets import read_send_file, recv_store_file

SEPARATOR = "<SEPARATOR>"
BUFFER_SIZE = 1024 * 4 #4KB
#FILE_NAME= "simon.txt"
#FILE_NAME= "playaencrypted.dat"
FILE_NAME_PREFIX= "fuchi"



LOCAL_HOST = 'localhost'
LOCAL_PORT = 8282
RESOURCE_DIRECTORY = Path(__file__).resolve().parent.parent / 'resources' / 'client'
CA_CERT = RESOURCE_DIRECTORY / 'ca.cert.pem'





def main(fname):
    """
    This is a client
    """
    # The code here create and configure an SSLContext, wrap a socket 
    # and connect using TLS
    # For help check out:
    #      https://github.com/mikepound/tls-exercises/blob/master/python/README.md

    # Create a standard TCP Socket
    sock= socket.socket(socket.AF_INET)
 

    # Create SSL context which holds the parameters for any sessions
    context= ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    context.check_hostname= False
    context.load_verify_locations(CA_CERT)
 

    # We can wrap in an SSL context first, then connect
    conn= context.wrap_socket(sock, server_hostname="Expert TLS Server")
    try:
        # Connect using conn

        # The code below is complete, it will use a connection to send and receive from the server

        conn.connect((LOCAL_HOST,LOCAL_PORT)) 

        # What parameters were established?
        print("Negotiated session using cipher suite: {0}\n".format(conn.cipher()[0]))

        # experimenting with simon.txt file stored on current subdir
        #filename= FILE_NAME 
        filename= fname 
        filesize= os.path.getsize(filename)

        # In python sockets send and receive strings. Send a string 
        conn.send(f"{filename}{SEPARATOR}{filesize}".encode())

        read_send_file(filename, filesize,  BUFFER_SIZE, conn)


        #####  client receiving response file from server #####
        print("cli_str.py now waiting from string from ser_str.py")
        #     Receive a string back from the server
        #     server_response = conn.recv(BUFFER_SIZE)
        received= conn.recv(BUFFER_SIZE).decode()
        filename, filesize= received.split(SEPARATOR)
        # remove filename path if any
        filename= os.path.basename(filename)
        filename= FILE_NAME_PREFIX + filename
        filesize= int(filesize)
        # start receiving the file from the socket
        # and writing to the file stream
        print("s.py will now read file from socket....")
        recv_store_file(filename, filesize, BUFFER_SIZE, conn)
        # Server response is a string, convert it to UTF-8 and print it 
        #print("Recvd from ser_str.py: ", server_response.decode("UTF-8").rstrip())

    finally:
        if conn is not None:
            conn.close()


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description="Client that sends and receives a files")
    parser.add_argument("file", help="File name to send")
    args = parser.parse_args()
    file_name = args.file 
    main(file_name)

