"""
title           : clia_pbb_secchan.py
description     : A client (Alice's) that sends a connection request
                : to a server, upon acceptance, the client sends
                : a request: either post s_A or retrieve.
                :
source          : https://pythonprogramming.net/pickle-objects-
                : sockets-tutorial-python-3/ 
                : 
author          : Carlos Molina Jimenez
date            : 26 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ser_pbb.py             on a window shell
                : % python3 clia_pbb_secchan.py  on another window shell
                :
                : % python3 clia_pbb_secchan.py -r post -t s_A
                : % python3 clia_pbb_secchan.py -r retrieve
                :
python_version  :     
                :
"""
import socket
import ssl
from pathlib import Path

# five new lines
import tqdm
import os
import argparse
import pickle

LOCAL_HOST = 'localhost'
LOCAL_PORT = 8282
RESOURCE_DIRECTORY = Path(__file__).resolve().parent.parent / 'resources' / 'client'
CA_CERT = RESOURCE_DIRECTORY / 'ca.cert.pem'


BUFFER_SIZE = 1024 * 4 #4KB
HEADERSIZE = 10 


class ClientPbb():

 def __init__(self):
  self.server= "localhost" 
  self.port= 8282 
  self.headersize= HEADERSIZE 
  self.s= None
  self.conn= None
  print("ClientPbb instance has been created")

 def sockconnect(self, ser="localhost", port=8282):
     self.server= ser
     self.port= port

     self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

     ###
     # Create a standard TCP Socket
     #sock= socket.socket(socket.AF_INET)
     #sock= socket.socket(socket.AF_INET,socket.SOCK_STREAM)
     # Create SSL context which holds the parameters for any sessions
     context= ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
     context.check_hostname= False
     context.load_verify_locations(CA_CERT)
     ###

     # We can wrap in an SSL context first, then connect
     self.conn= context.wrap_socket(self.s, server_hostname="Expert TLS Server")

     #s.connect((socket.gethostname(), 8282))
     return(self.conn.connect((ser, port)))

 def post(self, socket, token, hsize=HEADERSIZE):
     s= self.conn
     tkn= token 
     self.headersize= hsize 
     hdsize= hsize

     list = ["post", tkn]
     msg = pickle.dumps(list)
     msg = bytes(f"{len(msg):<{hdsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     s.send(msg)

     full_msg = b''
     new_msg = True
     full_msg_rcvd="NO"
     while full_msg_rcvd=="NO":
         print("post: Client waiting for new msg from server...")
         msg = s.recv(16)
         if new_msg:
             # take the first hdsieze_th elements of the list
             print("new msg len:",msg[:hdsize])
             msglen = int(msg[:hdsize])
             new_msg = False

         print(f"full message length: {msglen}")

         full_msg += msg

         print(len(full_msg))

         if len(full_msg)-hdsize == msglen:
             print("Full msg recvd")
             print(full_msg[hdsize:])
             print(pickle.loads(full_msg[hdsize:]))
             list=pickle.loads(full_msg[hdsize:])
             print("Msg received from server: ")
             for i in range(0, len(list)):
                 print("[", i, "]=", list[i])
             new_msg = True
             full_msg = b""
             full_msg_rcvd="YES"
     #s.close()



 def retrieve(self, socket, hsize=HEADERSIZE):
     s= self.conn
     self.headersize= hsize 
     hdsize= hsize

     list = ["retrieve"]
     msg = pickle.dumps(list)
     msg = bytes(f"{len(msg):<{hdsize}}", 'utf-8') + msg
     print(msg)
     # server sends to client
     s.send(msg)
     print("retrieve: Client has sent retrieve to server...")

     full_msg = b''
     new_msg = True
     full_msg_rcvd="NO"
     while full_msg_rcvd=="NO":
         print("retrieve: Client waiting for new msg from server...")
         msg = s.recv(16)
         if new_msg:
             # take the first hdsieze_th elements of the list
             print("new msg len:",msg[:hdsize])
             msglen = int(msg[:hdsize])
             new_msg = False

         print(f"full message length: {msglen}")

         full_msg += msg

         print(len(full_msg))

         if len(full_msg)-hdsize == msglen:
             print("Full msg recvd")
             print(full_msg[hdsize:])
             print(pickle.loads(full_msg[hdsize:]))
             list=pickle.loads(full_msg[hdsize:])
             print("Msg received from server: ")
             for i in range(0, len(list)):
                 print("[", i, "]=", list[i])
             new_msg = True
             full_msg = b""
             full_msg_rcvd="YES"
     #s.close()


if __name__ == "__main__":
   import argparse
   parser = argparse.ArgumentParser(description="A client to PBB with no sec chan")
   parser.add_argument("-s", "--server", help="Server implementing the PBB, default is local host", default= "localhost")
   parser.add_argument("-p", "--port", help="Port to use, default is 1243", default=1243)
   parser.add_argument("-r", "--request", help="Request to send, either post or retrieve, default is retrieve", default="retrieve")
   parser.add_argument("-t", "--token", help="Token to post", default="c_A")

   args = parser.parse_args()
   server  = args.server
   port    = args.port
   request = args.request
   token   = args.token

   c=ClientPbb()
   sockconnected= c.sockconnect()

   if request == "post":
      c.post(sockconnected, token, 10)  
   elif request == "retrieve":
      c.retrieve(sockconnected)  
   else:
      print("Error: in PBB call parameters")
 
   #sockconnected.close()
      
