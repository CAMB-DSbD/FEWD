#!/usr/bin/env python
"""
title           : tls.py
description     : Exploration of TLS-SSL
source          :  
author          : Carlos Molina Jimenez
date            : 20 Jun 2023 
version         : 1.0
usage           : 
notes           :
compile         : % python3 tls.py 
                :
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17)  
                :
====================================================
"""
import socket
import ssl

#hostname = 'www.python.org'
hostname = 'localhost'
context = ssl.create_default_context()

#with socket.create_connection((hostname, 443)) as sock:
with socket.create_connection((hostname, 8443)) as sock:
    with context.wrap_socket(sock, server_hostname=hostname) as ssock:
        print(ssock.version())

