#!/usr/bin/env python
"""
title           : sertls.py
description     : Exploration of TLS-SSL
source          :  
author          : Carlos Molina Jimenez
date            : 20 Jun 2023 
version         : 1.0
usage           : 
notes           :
compile         : % python3 sertls.py 
                :
python_version  : Python 3.7.4 (default, Oct  8 2019, 14:48:17)  
                :
====================================================
"""
import socket
import ssl

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
#context.load_cert_chain('/path/to/certchain.pem', '/path/to/private.key')
context.load_cert_chain('./resources/server/server.intermediate.chain.pem', './resources/server/server.key.pem')

with socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0) as sock:
    sock.bind(('127.0.0.1', 8443))
    sock.listen(5)
    with context.wrap_socket(sock, server_side=True) as ssock:
        conn, addr = ssock.accept()
#        ...
