#
#title           : scpayreceiptperations.py
#description     : This is the skeleton of a smart contract that
#                : shows the execution of a payment and send
#                : receipt operations.
#                : It is only a toy to show the ideas behind
#                : executable codes that are called smart contracts.
#                : It is meant to execute the following clauses:
#                : Clause 1: Bob shall deposit 100.00 euros to 
#                : Alice’s bank account on the 25th of Apr 2021 as a 
#                : donation to support the creation of a painting of 
#                : a black. 
#                : Clause 2: Alice shall spend 50.00 on the purchase of 
#                : material and send by post the receipts to Bob within 
#                : 5 days of receiving the money.
#author          : Carlos Molina-Jimenez 
#date            : 28 Dec 2020 (Computer Laboratory Univ of Cambridge)
#version         : 1
#notes           : 
#python_version  : Python 3.7.4   
#
#compile and run : python scpayreceiptoperations.py 
#                :
#result          : The program is meant to be launched on
#                  the 25th Apr 2021. After launch it checks
#                  the current date and a pay date. If it is
#                  pay date, it opens Bob's (the payer)
#                  bank account, withdraws 100.00 euros and 
#                  deposits them to Alice's (the payee) 
#                  bank account. Next it prints that the
#                  receipts have sent sent to Bob.
#
# online run     : I have run it succesfully on
#                  https://repl.it/languages/python3
#======================================================


from datetime import date
from datetime import datetime

aliceAcc= "A123"      # Alice's bank account
bobAcc= "B789"        # Bob's bank account
amount= 100           # amount to transfer from Alice to Bob. 
paydate= "28/12/2020" # pay date
paydone= "no"         # pay not performed yet
getDate= date.today()

today= getDate.strftime("%d/%m/%Y")
print("\n\ntoday is:", today)

if today == paydate:
   print("\n Bob, this code will pay Alice today, right now!\n")
   # 
   # Actual code to transfer money from Bob's account
   # to Alice's account to be included here.
   #
   print(str(100) + " euros have been transferred from Bob's to Alice's account\n")
   paydone= "yes"
else:
   now = datetime.now()
   deadline= datetime.strptime(paydate, "%d/%m/%Y")
   if now < deadline : 
      print("\n Bob, you have a pending deadline to pay on " + paydate + "\n")
   elif now > deadline:
      print("\n Bob, you have missed the pay deadline on " + paydate + "\n")


if paydone== "yes":
   #
   # Actual code to contact Alice (for ex by email) to get
   # the expenses receipts and forward them to Bob (for example
   # by email. The code waits for seven days for Alice's reply. If
   # Alice fails to reply the code sends a notification to Alice to
   # let her know about the missing deadline. This code assumes that
   # everything goes smoothly.
   #
   print("Alice, I've forward the receipts to Bob, well done!\n")


