#
#title           : scpayperation.py
#description     : This is the skeleton of a smart contract that
#                : shows the execution of a peyment operation.
#                : It is only a toy to show the ideas behind
#                : executable codes that are called smart contracts.
#                : It is meant to execute the following clause:
#                : Clause 1: Bob shall deposit 100.00 euros to 
#                : Alice’s bank account on the 25th of Apr 2021 as a 
#                : donation to support the creation of a painting of 
#                : a black. 
#author          : Carlos Molina-Jimenez 
#date            : 28 Dec 2020 (Computer Laboratory Univ of Cambridge)
#version         : 1
#notes           : 
#python_version  : Python 3.7.4   
#
#compile and run : python scpayoperation.py 
#                :
#result          : The program is meant to be launched on
#                  the 25th Apr 2021. After launch it checks
#                  the current date and a pay date. If it is
#                  pay date, it opens Bob's (the payer)
#                  bank account, withdraws 100.00 euros and 
#                  deposits them to Alice's (the payee) 
#                  bank account
#
# online run     : I have run it succesfully on
#                  https://repl.it/languages/python3
#======================================================


from datetime import date
from datetime import datetime

aliceAcc= "A123"      # Alice's bank account
bobAcc= "B789"        # Bob's bank account
amount= 100           # amount to transfer from Alice to Bob. 
paydate= "25/04/2021" # pay date

getDate= date.today()

today= getDate.strftime("%d/%m/%Y")
print("\n\ntoday is:", today)

if today == paydate:
   print("\n Bob, this code will pay Alice today, right now!\n")
   # 
   # Actual code to transfer money from Bob's account
   # to Alice's account to be included here.
   #
   print(str(100) + " euros have been transferred from Bob's to Alice's account\n")
else:
   now = datetime.now()
   deadline= datetime.strptime(paydate, "%d/%m/%Y")
   if now < deadline : 
      print("\n Bob, you have a pending deadline to pay on " + paydate + "\n")
   elif now > deadline:
      print("\n Bob, you have missed the pay deadline on " + paydate + "\n")

