#
#title           : smartcontractvr3py
#description     : This is a toy program to show how the code
#                : of a smart contract works. 
#author          : Carlos Molina Jimenez 
#date            : 28 Nov 2020 (Computer Laboratoty Univ of Cambridge)
#version         : 3
#notes           : 
#python_version  : Python 3.7.4   
#
#compile and run : python smartcontractv3.py 
#                :
#result          : it outputs an interactive menu that
#                  asks the user to say "y" or "no" to donate
#                  N pesos or decline. 
#                  Donations of different amounts are
#                  rejected. 
#                  If the donation is accepted the user is asked
#                  to provide his or her bank account number.
#                  The contract terminates after accpting a
#                  a single donation.
#                  The administrator of the collection can 
#                  type e to abruptly terminate the contract.
#
# online run     : I have run it succesfully on
#                  https://repl.it/languages/python3
#======================================================


# goal is the amount to collect. You can change it
# to any integer, for ex, 5, 10, 1000, etc.
goal = 500

# balance: amount of money collected 
balance = 0 
while balance < goal: 
  print("\n\n\n\n\n")

  print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
  print("===>>> Smart contract for Crowdfunding! <<<===\n")

  print("Alice is collecting " + str(goal) +  " pesos!\n")

  print("Alice's current balance is : " + str(balance) + " pesos \n")

  response= input("Donate " + str(goal) + " (type y | n or e to end): ? ")

  if response == "e":
     print("\n\n Warning: You have abruptly terminated the smart contract!\n\n")
     quit()
  elif response == "y":
     donation= int(input("Type amount: ? "))
     if donation ==  goal:
       balance = balance + donation 
       bankAccount= input("Type your bank account number: ")
       print("We are contacting your bank to collect payment ... ...")
       print("... ... ........ ... ...........  .......")
       print("Payment collected. Big thanks!")
     else: 
       print("Donation rejected.!")
       print("Only donations of " + str(goal) + " are accepted.")
  else:  
    print("Never mind, bye--bye!\n\n\n")
print("\n\nAlice's has already collected : " + str(balance) + " pesos\n\n\n")
print("We are contacting Alice's bank to deposit the money to her account... ...")
print("... ... ........ ... ...........  .......")
print("Money deposited! Well done Alice!\n\n")
