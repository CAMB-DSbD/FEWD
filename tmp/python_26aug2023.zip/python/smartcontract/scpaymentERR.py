#
#title           : payperations.py
#description     : This is the skeleton of a program that shows
#                : the execution of a peyment operation.
#author          : Carlos Molina Jimenez 
#date            : 28 Dec 2020 (Computer Laboratoty Univ of Cambridge)
#version         : 1
#notes           : 
#python_version  : Python 3.7.4   
#
#compile and run : python payoperation.py 
#                :
#result          : The program is meant to be launched on
#                  the 25th Apr 2010. After launch it opens Bob's
#                  (the payer) bank account, withdraws 100.00
#                  euros and deposits them to Alice's (the payee) 
#                  bank account
#
# online run     : I have run it succesfully on
#                  https://repl.it/languages/python3
#======================================================



from datetime import date
from datetime import datetime

aliceAcc= "A123"  # Alice's bank account
bobAcc= "B789"    # Bob's bank account
amount= 100       # amount to transfer from Alice to Bob. 
#paydate= "25/04/2021" # pay date
paydate= '28/12/2029' # pay date

now = datetime.now()
dl= datetime(2021, 25, 04)
if now == dl :
   print("\n Bob, you need to pay Alice today\n")
   # 
   # Actual code to transfer money from Bob's account
   # to Alice's account to be included here.
   #
   print(str(100) + " euros have been transferred from Bob's to Alice's account")
elif now < dl:
   print("\n Bob, you have a pending pay deadline\n")
else:
   print("\n Bob, you have missed the pay deadline\n")

