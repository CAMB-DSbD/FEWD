#
#title           : smartcontract.py
#description     : This is a toy program to show how the code
#                : of a smart contract works. 
#author          : Carlos Molina Jimenez 
#date            : 14 Nov 2020 (Computer Laboratoty Univ of Cambridge)
#version         : 1.0
#notes           : 
#python_version  : Python 3.7.4   
#
#compile and run : python smartcontract.py 
#                :
#result          : it outputs an interactive menu that
#                  asks the user to say "y" or "no", 
#                  to type the amount to donate and
#                  a bank account number.
#
# online run     : I have run it succesfully on
#                  https://repl.it/languages/python3
#======================================================


# goal is the amount to collect. You can change it
# to any integer, for ex, 5, 10, 1000, etc.
goal = 100


# balance: amount of money collected: increments from 0 to 100
balance = 0 
while balance < goal: 
  print("\n\n\n\n\n")

  print("Welcome to this Smart contract for Crowdfunding!\n")

  print("Alice is collecting 100 pesos!\n")

  print("Alice's current balance is : " + str(balance) + " pesos \n")

  donate= input("Would you like to contribute (type y or  n): ? ")

  if donate == "y":
    balance = balance + int(input("Type amount: ? "));
    bankAccount= input("Type your bank account number: ")
    print("We are contacting your bank to collect payment ... ...")
    print("... ... ........ ... ...........  .......")
    print("Payment collected. Big thanks!")
  else:  
    print("Never mind, bye--bye!\n\n\n")
print("\n\n\nAlice's has already collected : " + str(balance) + " pesos\n\n\n")
print("We are contacting Alice's bank to deposit the money to her account... ...")
print("... ... ........ ... ...........  .......")
print("Well done Alice!\n\n\n")

