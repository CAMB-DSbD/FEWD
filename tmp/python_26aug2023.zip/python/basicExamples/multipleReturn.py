#!/usr/bin/env python
#title           : multipleReturn.py
#description     : Demonstration of function that return several values  
#source          :  
#author          : Carlos Molina Jimenez
#date            : 30 Dec 2016
#version         : 1.0
#usage           : 
#notes           :
#compile and run : % python3 multipleReturn.py 
#python_version  : Python 3.6.0   
#====================================================

def returnMinMax(listOfNum):
   listOfNum.sort()
   return (listOfNum[0], listOfNum[-1])

listOfNum= [5, 10, 2, 4, 3, 8]

min, max= returnMinMax(listOfNum)

print ("The min vaule is: %d " % min)
print ("The max vaule is: %d " % max)
