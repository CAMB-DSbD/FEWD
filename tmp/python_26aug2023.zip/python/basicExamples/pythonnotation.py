"""
Meaning of python +=

Carlos Molina Jimenenez, carlos.molina@cl.cam.ac.uk
Date:  6 Jul 2023
"""

x= 1
y= 2
print("the value of x is ", x)
print("the value of y is ", y)

y += x  # it is like writing y= y + x
print("the value of y+= x is ", y, " It is like writing y= y + x")

