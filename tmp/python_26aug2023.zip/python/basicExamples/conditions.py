#!/usr/bin/env python
#title           : conditions.py
#description     : Demonstration of conditions and identation.  
#source          : https://www.learnpython.org/en/Hello,_World! 
#author          : Carlos Molina Jimenez
#date            : 30 Dec 2016
#version         : 1.0
#usage           : 
#notes           :
#compile and run : % python3 conditions.py 
#python_version  : Python 3.6.0   
#====================================================

x = 1
if x == 1:
    # indented four spaces
    print("x is 1.")
