#!/usr/bin/env python
#title           : int_to_string.py
#description     : Some testing about string conversion 
#author          : Carlos Molina Jimenez
#date            : 9 Mar 2017 
#version         : 1.0
#usage           : python int_to_string 
#notes           :
#compile and run : % python3 int_to_string.py 
#python_version  : Python 3.6.0   
#====================================================
import sys


n= 45
m= 90 

print("\n  print without conversion ")
print(n)
print(m)

print("\n  print after conversion into a string using str which adds a new line")
c1= str(n)
c2= str(m)
sys.stdout.write(c1)
sys.stdout.write(c2)

print("\n  print after a = a.replace(, ...) ")
s1=  str(n)
s2=  s1.replace("\n", " ")
s5=  str(m)
s6=  s5.replace("\n", " ")
sys.stdout.write(s2)
sys.stdout.write(s6)

