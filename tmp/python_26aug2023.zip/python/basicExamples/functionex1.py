#!/usr/bin/env python
#title           : functionex.py
#description     : Demonstration of function declaration  
#source          :  
#author          : Carlos Molina Jimenez
#date            : 30 Dec 2016
#version         : 1.0
#usage           : 
#notes           :
#compile and run : % python3 functionex.py 
#python_version  : Python 3.6.0   
#====================================================

# Definition of a polite function
def politeFun(inRudeSentence):
   politeSentence= inRudeSentence + '   please!'
   return politeSentence

print (politeFun('Dame una galleta')) 

