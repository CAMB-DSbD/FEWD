#!/usr/bin/env python
"""
title           : fun_xrange.py
description     : This code explains the use of the built in xragnge function1 
source          : https://wiki.python.org/moin/ForLoop 
author          : Carlos Molina Jimenez
date            : 25 Feb 2017
version         : 1.0
usage           : 
notes           :
compile and run : % python2 fun_xrange.py 
python_version  : Python 2.7.12   
                : It doesnt work on python 3
====================================================
"""


for x in xrange(3):
    print (x)
else:
    print ('Final x = %d' % (x))

