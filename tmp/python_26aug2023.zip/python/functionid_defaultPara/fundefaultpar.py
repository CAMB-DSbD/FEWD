#!/usr/bin/env python
"""
title           : fundefaultpar.py
description     : This code explains default parameters in functions 
source          : https://wiki.python.org/moin/ForLoop 
author          : Carlos Molina Jimenez
date            : 25 Feb 2017
version         : 1.0
usage           : 
notes           :
compile and run : % python2 fundefaultpar.py 
python_version  : Python 2.7.12   
                : It doesnt work on python3
====================================================
"""

def function(data=[]):
    data.append(1)
    return data

def func(data=[]):
    data.append(1)
    return data



"""
The function keeps using the same object, in each 
call. The modifications we make are sticky.
"""
for x in xrange(5):
    l= function()


for x in l:
 print(x)


for x in xrange(5):
    print(id(func()))



"""
The workaround is, as others have mentioned, to use a 
placeholder value instead of modifying the default value. 
None is a common value:
"""
def myfunc(value=None):
    if value is None:
       value = []
       # modify value in the following lines 
       value.append(5)
    return value

for x in xrange(5):
    lst= myfunc() # No parameter is passed to the function
                  # the default (value= []) is used.

for x in lst:
 print(x)


for x in xrange(5):
    lst= myfunc([77])

for x in lst:
 print(x)

