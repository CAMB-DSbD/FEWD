"""
title           : memoryUsed.py 
description     : runs a shell that returns the current free memory.  
source          : https://docs.python.org/3/library/subprocess.html 
author          : Carlos Molina Jimenez
date            : 30 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3  
python_version  : Python 2   
====================================================
"""

"""
$ free -k | grep Mem: | awk '{print $3}'  shows only info about used memory  
111468                                    $3 indicates the extraction of   
                                          the 3rd string in the line       
                                          produced by '$ free -k'           
Explanation and ex
http://sharats.me/the-ever-useful-and-neat-subprocess-module.html

"""

from subprocess import Popen, PIPE

proc = Popen('ls', stdout=PIPE)
s= proc.stdout.read()

#s=[]
#for line in proc.stdout:
#    s.append(line)
print s 

