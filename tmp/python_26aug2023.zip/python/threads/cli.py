"""
title           : cli.py
description     : threads in actions: a client server implementation over
                  sockets and threads. 
source          : http://54.254.151.224:8080/media_ebook/PyThreads.pdf 
author          : Carlos Molina Jimenez
date            : 3 Jul 2017 
version         : 1.0
usage           : 
notes           :
python_version  : Python 2.7.12   
complie and run :
                  1) I run this on my Mac Book Air.
                  bash-3.2$ hostname
                  carlossair20041.home

                  2) python  ser.py 2000
 
                  3) In another window shell I typed
                     python cli.py carlossair20041.home 2000

                  4) In another window shell I typed
                     python cli.py carlossair20041.home 2000 
====================================================
"""

"""
simple illustration client of thread module
two clients connect to server; each client repeatedly sends a
value k, which the server adds to a global value v and echoes back
to the client; k = 0 means the client is dropping out; when all
clients gone, server prints the final value of v
the values k are sent as single bytes for convenience; it is assumed
that neither k nor v ever exceed 255
this is the client; usage is
 
python clnt.py server_address port_number

"""

import socket
import sys

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = sys.argv[1] # server address

port = int(sys.argv[2]) # server port
s.connect((host, port))

while(1):
  d = raw_input('input k: ')
  k = int(d)
  s.send(chr(k)) # send k as one byte
  if k == 0: break
  d = s.recv(1) # receive v as one byte
  print ord(d) # print v

s.close()


