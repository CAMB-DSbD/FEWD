#!/usr/bin/env python
"""
title           : thread_with_param.py
description     : this a is basic example of threading.  It shows how to pass parameters
source          : www.bogotobogo.com/python/Multithread/python_multithreading_creating_threads.php 
author          : Carlos Molina Jimenez
date            : 21 mar 2017 
version         : 1.0
usage           : 
notes           :
compile and run : % python thread_with_param.py 
python_version  : Python 2.7.12   
====================================================
"""

"""
The Thread class is defined in http://hg.python.org/cpython/file/3.4/Lib/threading.py.

The __init__() of the Thread class looks like this:

def __init__(self, group=None, target=None, name=None,
             args=(), kwargs=None, *, daemon=None):
"""

# 

import threading

def myfunc(n):
    print (' thread function ' + str(n))
    return

if __name__ == '__main__':
    for i in range(3):
        t1 = threading.Thread(target=myfunc, args=(i,))
        t2 = threading.Thread(target=myfunc, args=(i,))
        t3 = threading.Thread(target=myfunc, args=(i,))
        t1.start()
        t2.start()
        t3.start()

