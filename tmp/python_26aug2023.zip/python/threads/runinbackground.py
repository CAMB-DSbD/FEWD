#!/usr/bin/env python
"""
title           : runinbackground.py
description     : this a is basic example of threading to show a method
                : running in the background.
source          : http://sebastiandahlgren.se/2014/06/27/running-a-method-as-a-background-thread-in-python/ 
author          : Carlos Molina Jimenez
date            : 21 mar 2017 
version         : 1.0
usage           : 
notes           :
compile and run : % python runinthebackground.py 
python_version  : Python 2.7.12   
====================================================
"""


import threading
import time


class ThreadingExample(object):
    """ Threading example class
    The run() method will be started and it will run in the background
    until the application exits.
    """

    def __init__(self, interval=1):
        """ Constructor
        :type interval: int
        :param interval: Check interval, in seconds
        """
        self.interval = interval

        thread = threading.Thread(target=self.runinbackground, args=())
        thread.daemon = True                            # Daemonize thread
        thread.start()                                  # Start the execution

    def runinbackground(self):
        """ Method that runs forever """
        while True:
            # Do something
            print('Doing something imporant in the background')

            time.sleep(self.interval)

example = ThreadingExample()
time.sleep(3)
print('Checkpoint')
time.sleep(2)
print('Bye')

