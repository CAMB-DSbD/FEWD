#!/usr/bin/env python
"""
title           : thread_prnt.py
description     : this a is basic example of threading. 
source          : www.bogotobogo.com/python/Multithread/python_multithreading_creating_threads.php 
author          : Carlos Molina Jimenez
date            : 21 mar 2017 
version         : 1.0
usage           : 
notes           :
compile and run : % python thread_prnt.py 
python_version  : Python 2.7.12   
====================================================
"""

"""
The Thread class is defined in http://hg.python.org/cpython/file/3.4/Lib/threading.py.

The __init__() of the Thread class looks like this:

def __init__(self, group=None, target=None, name=None,
             args=(), kwargs=None, *, daemon=None):
"""

# 

import threading

def f():
    print ('thread function')
    return

if __name__ == '__main__':
    for i in range(3):
        t = threading.Thread(target=f)
        t.start()

