"""
title           : ser.py
description     : threads in actions: a client server communication
                  over sockets. The server uses threads. 
source          : http://54.254.151.224:8080/media_ebook/PyThreads.pdf 
author          : Carlos Molina Jimenez
date            : 3 Jul 2017 
version         : 1.0
usage           : 
notes           : 
python_version  : Python 2.7.12   
complie and run :
                  1) I run this on my Mac Book Air.
                  bash-3.2$ hostname
                  carlossair20041.home

                  2) python  ser.py 2000
 
                  3) In another window shell I typed
                     python cli.py carlossair20041.home 2000

                  4) In another window shell I typed
                     python cli.py carlossair20041.home 2000 
====================================================
"""

"""
simple illustration client of thread module 2
multiple clients connect to server; each client repeatedly sends a
value k, which the server adds to a global value v and echoes back
to the client; k = 0 means the client is dropping out; when all
clients gone, server prints final value of v

the values k are sent as single bytes for convenience; it is assumed
that neither k nor v ever exceeds 255 

"""

import socket
import sys

import thread

# thread to serve a client
def serveclient(c,i):
 global v, num_cli, num_cli_lock
 # gloabl variables are shared between all threads
 # v is used for storing a value that all threads can alter
 # num_cli is used to report to the main program when the
 #         thread complestes.
 while 1:
   d = c.recv(1)
   k = ord(d)
   if k==0:
      break
   vlock.acquire()
   v+=k
   vlock.release()
   c.send(chr(v))
 c.close()
 vlock.acquire()
 num_cli -= 1
 vlock.release()

lstn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
port = int(sys.argv[1])
lstn.bind(('', port))
lstn.listen(5)

v=0
vlock = thread.allocate_lock()
num_cli =2


num_cli_lock = thread.allocate_lock()


for i in range(2): # two threads are created
 (cli,addr) = lstn.accept()
 print("\nThread to deal with cli " + str(i) + " has been created\n")
 thread.start_new_thread(serveclient,(cli,i))

# wait for both threads to exit
while num_cli > 0: pass
#  print("\nThere are " + str(num_cli) + " still running\n")

lstn.close()
