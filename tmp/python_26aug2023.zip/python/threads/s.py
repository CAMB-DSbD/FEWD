"""
title           : ser.py
description     : threads in actions: a client server communication
                  over sockets. The server uses threads. 
source          : http://54.254.151.224:8080/media_ebook/PyThreads.pdf 
author          : Carlos Molina Jimenez
date            : 3 Jul 2017 
version         : 1.0
usage           : 
notes           :
compile and run : % python 
python_version  : Python    
====================================================
"""

"""
simple illustration client of thread module 2
multiple clients connect to server; each client repeatedly sends a
value k, which the server adds to a global value g and echoes back
to the client; k = 0 means the client is dropping out; when all
clients gone, server prints final value of g

the values k are sent as single bytes for convenience; it is assumed
that neither k nor g ever exceeds 255 

this is the server
"""

import socket
import sys

import thread

# thread to serve a client
def serveclient(c,i):
 global v, num_cli, num_cli_lock
 while 1:
   d = c.recv(1)
   k = ord(d)
   if k==0:
      break
   vlock.acquire()
   v+=k
   vlock.release()
   c.send(chr(v))
 c.close()
 vlock.acquire()
 num_cli -= 1
 vlock.release()

lstn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
port = int(sys.argv[1])
lstn.bind(('', port))
lstn.listen(5)

v=0
vlock = thread.allocate_lock()
num_cli =2


num_cli_lock = thread.allocate_lock()


for i in range(2):
 (cli,addr) = lstn.accept()
 print("\nThread to deal with cli " + str(i) + " has been created\n")
 thread.start_new_thread(serveclient,(cli,i))

# wait for both threads to exit
while num_cli > 0: pass
#  print("\nThere are " + str(num_cli) + " still running\n")

lstn.close()
