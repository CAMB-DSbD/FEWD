#!/usr/bin/env bash

# Generate RSA private key and store it in a local
# file named private_key.pem
#
# OpenSSL is  a command line tool available in linux
# genrsa    Generation of RSA Private Key. Superceded by genpkey.
#
openssl genrsa -out alice_private_key.pem 1024
