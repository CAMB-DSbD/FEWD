""" 
  Programmer: Carlos Molina
  Source: https://gist.github.com/cevaris/e003cdeac4499d225f06 
  Date: 13 Sep 2019 
  Purpose: It demosntrates how to sign a message by means of
           signing a digest of the message. 
   
  Execution on my MacBookAir: 
  0) the pycrypto==2.6.1 is expected to be installed. I installed 
     it with 
     bash-3.2$  export "CFLAGS=-I/usr/local/include -L/usr/local/lib"
     bash-3.2$ pip3 install pycrypto

  1) Generate iprivate key 
     % ./generate_key.sh
     File private_key.pem is created in local folder 
     it contains
     -----BEGIN RSA PRIVATE KEY-----
     MIICXAIBAAKBgQDQQKiPeEvDUjE2XT ....
     -----END RSA PRIVATE KEY-----

  2) Execute sign_verify.py  
     I have bash-3.2$ python3
            Python 3.7.4 (v3.7.4:e09359112e, Jul  8 2019, 14:36:03) 

     bash-3.2$ python3 sign_verify.py
     Successfully verified message
"""

from base64 import (
    b64encode,
    b64decode,
)

from Crypto.Hash import SHA256
from Crypto.Signature import PKCS1_v1_5
from Crypto.PublicKey import RSA


message = "I want this contract to be signed by Alice".encode('utf-8')

# The program signs a digest of the original message (see NEEb1993,
# p533).
digest = SHA256.new()
digest.update(message)


# Read alice private that % generate_key.sh has previously
# created and stored in the alice_private_key.pem local file
alice_private_key = False
with open ("alice_private_key.pem", "r") as myfile:
    alice_private_key= RSA.importKey(myfile.read())


# Load alice private key and sign the digit, basucally, the
# digit is encrypted with alice's private key. Since only
# alice knows this key, it follows that only Alice could
# have encrypted the digit.
signer = PKCS1_v1_5.new(alice_private_key)
signedMsg = signer.sign(digest)


"""
Use the public key associated to alice_private_key to
verify that signed_Msg is signed under alice_private_key.

This step is supossed to be executed by Bob who can
retrive alice's public key from a public repository.
In this example, the public key is retrived by this
program from the local file named alice_private_key.pem
"""
# 1st) Load Alice's public key to the verifier
verifier = PKCS1_v1_5.new(alice_private_key.publickey())

# 2nd) use alice's public key to decrypt signedMsg and
#      compare it against the original digest.
verified = verifier.verify(digest, signedMsg)

# 3rd) print Successfully verified only if the comparison
#      is correct.
assert verified, 'Signature verification failed'
print ('Successfully verified')

