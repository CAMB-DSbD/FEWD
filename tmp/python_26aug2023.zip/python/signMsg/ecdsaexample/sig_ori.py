"""
title           : sig_ori.py
description     : A demo of the ecdsa library. It creates a symmetric
                : keyt to sign and verify the signature place on a
                : text message after convering it to byte format. 
                :
source          :  https://www.educative.io/answers/how-to-create-digital-
                :  signature-in-python-using-ecdsa-signingkey
                : 
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 sig_ori.py 
                : 
                : b'\xd4\x1b\x80\xbb\xe5\xd9Il\xb5[ \x9a&\xbf\xb3 k\xbd\x0e\
                :  xeb@L\xa6\x88\xe3H\xe4;i\xc6zt\xb6\x17\xda\xc2\x1e\xe3\xa3!
                :  \xa4\x1f\x96\xa3v\xf5V<'
                :  Signature verification OK
                :
                :  Change the text of the msg in verify_key to get
                :  an exception.
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""

from ecdsa import SigningKey # import the SigningKey class

priv_key = SigningKey.generate() # uses NIST192p

# https://stackoverflow.com/questions/34451214/
# how-to-sign-and-verify-signature-with-ecdsa-in-python
verify_key=  priv_key.get_verifying_key()

signature = priv_key.sign(b"Las iguanas verdes")

print(signature)


if verify_key.verify(signature, b"Las iguanas verdes") == True:
   print("Signature verification OK")
else:
   raise Exception(" Signature verification failed")



