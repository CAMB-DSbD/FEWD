"""
title           : ecdhAlice.py
description     : Demostrates a run of ECDH protocol between
                : Alice and Bob to exchange a secret. 
                : It runs in combination with ecdhBob.py which
                : its more sophisticated and documented.
                :
source          : https://pypi.org/project/ecdsa/ 
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 ecdhAlice.py
                : 
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""


from ecdsa import ECDH, NIST256p

def createPubKey():
    ecdh = ECDH(curve=NIST256p)
    ecdh.generate_private_key()
    alice_local_pubK = ecdh.get_public_key()

    alice_local_pubK.pem= alice_local_pubK.to_pem()

    with open("alice_local_pubK.pem", "wb") as f:
         f.write(alice_local_pubK.pem)
    return ecdh


def recoverSecret(ecdh):
    with open("bob_local_pubK.pem") as e:
         bob_local_pubK = e.read()
    ecdh.load_received_public_key_pem(bob_local_pubK)
    alice_bob_secret = ecdh.generate_sharedsecret_bytes()
    print("\nAlice has recovered the secret exchanged with Bob")
    print("Secret on Alice's side: ", bytes(alice_bob_secret))
    print("\n")
    print("\n")
    with open("alice_bob_secret", "wb") as f:
         f.write(alice_bob_secret)   


def readsecret():
    with open("alice_bob_secret", "rb") as f:
     alice_bob_secret = f.read()
    print("Secret on Alices's side retreived from disk: ", bytes(alice_bob_secret))
    print("\n")



myinput=0
while (int(myinput) <= 2):
 myinput = input("1 : createPubKey or 2: recoverSecret or 3: bye)?")
 if 1 == int(myinput):
    print("input 1= ", int(myinput))
    ecdh=createPubKey()
 elif 2 == int(myinput):
    print("input 2= ", int(myinput))
    recoverSecret(ecdh)
 elif 3 == int(myinput):
    print("input 3= ", int(myinput), "bye")
    readsecret()
    myinput= 3






