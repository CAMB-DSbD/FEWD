"""
title           : ecdhBob.py
description     : Demostrates a run of ECDH protocol between
                : Alice (ecdsaAlice.py) and Bob (ecdsaBob.py) to 
                : exchange a secret. 
                : It signs a message with the shared secret.
                : 
                :
source          : https://pypi.org/project/ecdsa/ 
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 ecdhBob.py  # see run and output below
                : 
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""

"""
bash-3.2$ py ecdhBob.py

1 : createPubKey or 2: recoverSecret or 3: bye)?1
input 1=  1
         /*
          * stop here and copy manually, bob_local_pubK.pem
          * to Alice's folder and alice_local_pubK.pem   
          * to Bob's folder.
          */

1 : createPubKey or 2: recoverSecret or 3: bye)?2
input 2=  2

Bob has recovered the secret exchanged with Alice
Secret on Bob's side:  b'A\xdf\x96\x9a\xb9\xda\xea\x82~\xfe\xbb*\xce\x84-l\xb8\xabD\xaaziX.:\xd0\xba\x8f\xd3\xab*M'


1 : createPubKey or 2: recoverSecret or 3: bye)?3
input 3=  3 bye
Secret on Bob's side retrieved from disk:  b'A\xdf\x96\x9a\xb9\xda\xea\x82~\xfe\xbb*\xce\x84-l\xb8\xabD\xaaziX.:\xd0\xba\x8f\xd3\xab*M'


this hash  98ec4a9bf61549360e22edbb6701dad8  encodes Bob's msg and alice_bob_secret
 
 thus, can be presented to Alice as Bob's commitment Bob's msg
"""



import hashlib

from ecdsa import ECDH, NIST256p

def createPubKey():
    ecdh = ECDH(curve=NIST256p)
    ecdh.generate_private_key()
    bob_local_pubK = ecdh.get_public_key()

    bob_local_pubK.pem= bob_local_pubK.to_pem()

    with open("bob_local_pubK.pem", "wb") as f:
         f.write(bob_local_pubK.pem)
    return ecdh

def recoverSecret(ecdh):
    with open("alice_local_pubK.pem") as e:
         alice_local_pubK = e.read()
    ecdh.load_received_public_key_pem(alice_local_pubK)
    alice_bob_secret = ecdh.generate_sharedsecret_bytes()
    print("\nBob has recovered the secret exchanged with Alice")
    print("Secret on Bob's side: ", bytes(alice_bob_secret))
    print("\n")
    with open("alice_bob_secret", "wb") as f:
         f.write(alice_bob_secret) 

def readsecret():
    with open("alice_bob_secret", "rb") as f:
     alice_bob_secret = f.read()
    print("Secret on Bob's side retrieved from disk: ", bytes(alice_bob_secret))
    print("\n")
    return alice_bob_secret


def signMsgWithSecret(msg, alice_bob_secret):
    mstr= msg + str(alice_bob_secret)  # this works OK
    mbytes= msg.encode("utf-8") + alice_bob_secret
    myhash_mbytes = hashlib.md5(mbytes) 
    print("this hash ", myhash_mbytes.hexdigest(), " encodes Bob's msg and alice_bob_secret")
    print(" \n thus, can be presented to Alice as Bob's commitment Bob's msg")
    # only bob knows msg to make hash(msg + alice_bob_secret) and myhash_mbytes to match
    #

myinput=0
while (int(myinput) <= 2):
 myinput = input("1 : createPubKey or 2: recoverSecret or 3: bye)?")
 if 1 == int(myinput):
    print("input 1= ", int(myinput))
    ecdh=createPubKey()
 elif 2 == int(myinput):
    print("input 2= ", int(myinput))
    recoverSecret(ecdh)
 elif 3 == int(myinput):
    print("input 3= ", int(myinput), "bye")
    alice_bob_secret= readsecret()
    signMsgWithSecret("See u tomo at 5pm", alice_bob_secret)
    myinput= 3


