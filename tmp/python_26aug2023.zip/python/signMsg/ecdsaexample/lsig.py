"""
title           : sig_and_list.py
description     : A demo of the ecdsa library. It creates a symmetric
                : key to sign and verify the signature place on 
                : elements of a list after convering it to byte format.
                :
source          :  https://www.educative.io/answers/how-to-create-digital-
                :  signature-in-python-using-ecdsa-signingkey
                :
                : https://pypi.org/project/ecdsa/
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 sig_and_list.py
                : 
                : b'\xd4\x1b\x80\xbb\xe5\xd9Il\xb5[ \x9a&\xbf\xb3 k\xbd\x0e\
                :  xeb@L\xa6\x88\xe3H\xe4;i\xc6zt\xb6\x17\xda\xc2\x1e\xe3\xa3!
                :  \xa4\x1f\x96\xa3v\xf5V<'
                :  Signature verification OK
                :
                :  Change the text of the msg in verify_key to get
                :  an exception.
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""

import pickle

from ecdsa import SigningKey # import the SigningKey class


"""
Experimenting with ascii and byte elements in a list
"""

def ascii2utf8(ascii_lst):
    utf8_lst=[]
    for i in range(0, len(ascii_lst)):
        utf8_lst.append(ascii_lst[i].encode("utf-8"))
    return utf8_lst 

# https://stackoverflow.com/questions/34451214/
# how-to-sign-and-verify-signature-with-ecdsa-in-python

lstascii=["s_A", "s_B", "c_A", "c_A", "c_B"]

#l= map(str.encode("utf-8"), lstascii)

lstutf8= ascii2utf8(lstascii)

    

separator=" "

eles=separator.join(lstascii)

elesutf8= eles.encode("utf-8")

priv_key = SigningKey.generate() # uses NIST192p
verify_key=  priv_key.get_verifying_key()

sig_elesutf8= priv_key.sign(elesutf8)
print("sig_elesutf8: ", sig_elesutf8)

byteB= b"s_B"

print("\nlength lstutf8= ", len(lstutf8))
for x in range (0, len(lstutf8)):
    print("ele= ", lstutf8[x])

#lstutf8_withsig= lstutf8.append(byteB) # wrong
lstutf8.append(sig_elesutf8) #sent to reveiver


print("\nlength lstutf8= ", len(lstutf8))
for x in range (0, len(lstutf8)):
    print("ele= ", lstutf8[x])
 
print("\nlength lstutf8_withsig= ", len(lstutf8))

lstutf8_withsig= lstutf8

print("\nlength lstutf8_withsig= ", len(lstutf8_withsig))
for x in range (0, len(lstutf8_withsig)):
    print("ele= ", lstutf8_withsig[x])

"""
You can include the following line to make signature
verification fail
"""
#lstutf8_withsig[0]= byteB= b"c_A" 


print("\nReceiver verifies signature")

recv_lstutf8_withsig= lstutf8_withsig 

if len(recv_lstutf8_withsig) >= 1 :
   sig= recv_lstutf8_withsig.pop()
   recv_lstutf8_withoutsig= recv_lstutf8_withsig 
else:
   raise Exception("Erroneous response from PBB")

recv_lstascii= map(bytes.decode, recv_lstutf8_withoutsig)
lll= list(recv_lstascii)

print("\nlength lll= ", len(lll))
for x in range (0, len(lll)):
    print("ele= ", lll[x])


sep=" "

elems=sep.join(lll)

elemsutf8= elems.encode("utf-8")


# https://www.geeksforgeeks.org/python-program-to-concatenate-all-elements-of-a-list-into-a-string/

################  assert vk.verify(signature, b"message")


if verify_key.verify(sig,elemsutf8) == True:
   print("Signature verification OK for recv_lstutf8_withsig")
else:
   raise Exception("Signature verification failed for recv_lstutf8_withsig")

