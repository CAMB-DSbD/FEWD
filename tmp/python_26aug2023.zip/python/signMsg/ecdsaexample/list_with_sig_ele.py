"""
title           : list_with_sig_ele.py
description     : A demo of the ecdsa library. It creates a pair of 
                : keys: privK and pubK.
                : priK is used for signing the elements of a list
                : pubK is used for verifying  the signature. 
                :
source          :  https://www.educative.io/answers/how-to-create-digital-
                :  signature-in-python-using-ecdsa-signingkey
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 list_with_sig_ele.py
                : 
                : b'\xd4\x1b\x80\xbb\xe5\xd9Il\xb5[ \x9a&\xbf\xb3 k\xbd\x0e\
                :  xeb@L\xa6\x88\xe3H\xe4;i\xc6zt\xb6\x17\xda\xc2\x1e\xe3\xa3!
                :  \xa4\x1f\x96\xa3v\xf5V<'
                :  Signature verification OK
                :
                :  Change the text of the msg in verify_key to get
                :  an exception.
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""


from ecdsa import SigningKey # import the SigningKey class


"""
Experimenting with ascii and byte elements in a list
"""




# https://stackoverflow.com/questions/34451214/
# how-to-sign-and-verify-signature-with-ecdsa-in-python

priK = SigningKey.generate() # uses NIST192p
pubK=  priK.get_verifying_key() # generate corresponding pubK


eleA_ascii= "s_A"
eleB_ascii= "s_B"

# Just testing conversion through the  bytes function
# to ascii
#byteeleA= b"s_A"
#byteeleB= b"s_B"

eleA_byte= bytes(eleA_ascii, "utf-8")
eleB_byte= bytes(eleB_ascii, "utf-8")

lst_bytes=[eleA_byte, eleB_byte]

print("\n Elements in ascci format:")
for x in range(0, len(lst_bytes)):
    print("lst_ascii[", x, "]=",lst_bytes[x].decode("ascii"))

print("\n Elements in byte (utf-8) format:")
for x in range(0, len(lst_bytes)):
    print("lst_bytes[", x, "]=",lst_bytes[x])


print("\n priK used to produce signatures ")
sigA = priK.sign(eleA_byte)
sigB = priK.sign(eleB_byte)

print(" sigA: " , sigA)
print("\n sigB: " , sigB)

lst_sig_and_its_ele=[sigA, eleA_byte, sigB, eleB_byte] #list with sigs

print("\nUse pubK to verify signatures ")
x=0
while (x <= len(lst_sig_and_its_ele)-1):
  if pubK.verify(lst_sig_and_its_ele[x], lst_sig_and_its_ele[x+1]) == True:
     print("Signature verification OK for lst_sig_and_its_ele[", x+1 ,"]")
     x= x+2
  else:
     raise Exception("Signature verification failed lst_sig_and_its_ele[", x+1 ,"]")

