"""
title           : listflat.py
description     : A demo of concatenation operations on
                : a list. 
                :
source          : https://www.geeksforgeeks.org/python-program-
                : to-concatenate-all-elements-of-a-list-into-a-string/  
                :
                : map https://realpython.com/python-map-function/
                :
                : separator
                : https://www.w3schools.com/python/ref_string_join.asp
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 listflat.py
                : 
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""


"""
Experimenting with ascii and byte elements in a list
"""

"""
Convert the number 3.5 into an string: x = str(3.5)
str(object, encoding=encoding, errors=errors)
"""

lst = [ 'hello', 'geek', 'have',
     'a', 'geeky', 'day']
 
res = " ".join(map(str, lst))
print(res)


lst = [ 'hello', 'geek', 'have',
     'a', 'geeky', 'day']
 
res = " ".join(map(str.upper, lst))
print("map effect:  ",res)



res = " ".join(lst)
print("join effect:  ",res)


carlosseparator="<#>"
res = carlosseparator.join(lst)
print("carlosseparator effect:  ",res)

noseparator=""
res = noseparator.join(lst)
print("noseparator effect:  ",res)

