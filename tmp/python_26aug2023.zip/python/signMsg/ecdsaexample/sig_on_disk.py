"""
title           : sig_on_disk.py
description     : Demostrates how sign and verify keys
                : can be stored to and retrieved from
                : disk and operatr with messages stored
                : and retrieved from disk.
                : It uses keys retrived from disk (sk and vk) to
                : a) sign the elements of a list
                : b) verify  the signature. 
                :
source          : https://pypi.org/project/ecdsa/ 
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 sig_on_disk.py
                : Verification of signature on message SUCCEDED
                : ... 
                : Signature verification OK for lst_sig_and_its_ele[ 3 ] 
                :
                :  Change the text of the msg in verify_key to get
                :  an exception.
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""


from ecdsa import SigningKey, VerifyingKey, BadSignatureError

# Create a NIST192p key pair and immediately save both to disk:

# 1) create signing key
#sk = SigningKey.generate(curve=NIST192p) Ok but needs to import NIST192p
sk = SigningKey.generate() # uses NIST192p by default

# 2) create corresponding verification key
vk = sk.verifying_key

# 3) Store sign key (sk) on disk
with open("private.pem", "wb") as f:
    f.write(sk.to_pem())

# 4) Store verify key (vk) on disk
with open("public.pem", "wb") as f:
    f.write(vk.to_pem())

# Load a signing key from disk, use it to sign a message 
# (using SHA-1), and write the signature to disk:

# 5) Retrieve sign key (sk) from disk
with open("private.pem") as f:
    sk = SigningKey.from_pem(f.read())

# 6) Retrieve message from disk
with open("message", "rb") as f:
    message = f.read()

# 7) Use sign key to sign message 
sig = sk.sign(message)

# 8) Store signed message (signature)  on disk
with open("signature", "wb") as f:
    f.write(sig)

"""
Load the verifying key, message, and signature 
from disk, and verify the signature (assume SHA-1 hash):
"""

# 9) Retrieve verify key (vk) from disk
vk = VerifyingKey.from_pem(open("public.pem").read())


# 10) Retrieve message from disk
with open("message", "rb") as f:
    message = f.read()


# 11) Retrieve signed message (signature) from disk
with open("signature", "rb") as f:
    sig = f.read()


# 12) Use verify key (vk) to verify the signature of
#     message. 
try:
    vk.verify(sig, message)
    print("Verification of signature on message SUCCEDED")
except BadSignatureError:
    print("Verification of signature on message FAILED")

### Retrieve sk and vk from disk to work with the list ###
eleA_ascii= "s_A"
eleB_ascii= "s_B"

# Just testing conversion through the  bytes function
# to ascii
#byteeleA= b"s_A"
#byteeleB= b"s_B"

eleA_byte= bytes(eleA_ascii, "utf-8")
eleB_byte= bytes(eleB_ascii, "utf-8")

lst_bytes=[eleA_byte, eleB_byte]

print("\n Elements in ascci format:")
for x in range(0, len(lst_bytes)):
    print("lst_ascii[", x, "]=",lst_bytes[x].decode("ascii"))

print("\n Elements in byte (utf-8) format:")
for x in range(0, len(lst_bytes)):
    print("lst_bytes[", x, "]=",lst_bytes[x])


# Retrieve sign key (sk) from disk
with open("private.pem") as f:
    sk = SigningKey.from_pem(f.read())

print("\n sk  used to produce signatures ")
sigA = sk.sign(eleA_byte)
sigB = sk.sign(eleB_byte)

print(" sigA: " , sigA)
print("\n sigB: " , sigB)

lst_sig_and_its_ele=[sigA, eleA_byte, sigB, eleB_byte] #list with sigs


# Retrieve verify key (vk) from disk
vk = VerifyingKey.from_pem(open("public.pem").read())


print("\nUse vk to verify signatures ")
x=0
while (x <= len(lst_sig_and_its_ele)-1):
  if vk.verify(lst_sig_and_its_ele[x], lst_sig_and_its_ele[x+1]) == True:
     print("Signature verification OK for lst_sig_and_its_ele[", x+1 ,"]")
     x= x+2
  else:
     raise Exception("Signature verification failed lst_sig_and_its_ele[", x+1 ,"]")

