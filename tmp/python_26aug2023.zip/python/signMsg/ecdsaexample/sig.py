"""
title           : listwithsig.py
description     : A demo of the ecdsa library. It creates a symmetric
                : key to sign and verify the signature place on 
                : elements of a list after convering it to byte format.
                : It consists of two pieces
                : 1) The sender that sends de list
                : 2) The receiver that reeives the list
                :
source          :  https://www.educative.io/answers/how-to-create-digital-
                :  signature-in-python-using-ecdsa-signingkey
                :
                : https://pypi.org/project/ecdsa/
                :
author          : Carlos Molina Jimenez
date            : 28 Jul 2023
version         : 1.0
usage           :
notes           :
compile and run : % python3 listwithsig.py
                : 
                : b'\xd4\x1b\x80\xbb\xe5\xd9Il\xb5[ \x9a&\xbf\xb3 k\xbd\x0e\
                :  xeb@L\xa6\x88\xe3H\xe4;i\xc6zt\xb6\x17\xda\xc2\x1e\xe3\xa3!
                :  \xa4\x1f\x96\xa3v\xf5V<'
                :  Signature verification OK
                :
                :  Change the text of the msg in verify_key to get
                :  an exception.
python_version  : Python 3.7.4(v3.7.4:e09359112e, Jul 8 2019, 14:36:03) 
                :
"""

import pickle

from ecdsa import SigningKey # import the SigningKey class


"""
Experimenting with ascii and byte elements in a list
"""

def ascii2utf8(ascii_lst):
    utf8_lst=[]
    for i in range(0, len(ascii_lst)):
        utf8_lst.append(ascii_lst[i].encode("utf-8"))
    return utf8_lst 



##########The sender's end############

# https://stackoverflow.com/questions/34451214/
# how-to-sign-and-verify-signature-with-ecdsa-in-python

lstascii=["s_A", "s_B", "c_A", "c_A", "c_B"]

print("\nlstascii:")
for x in range (0, len(lstascii)):
    print("ascii_ele= ", lstascii[x])

lstutf8= ascii2utf8(lstascii)
print("\nlstutf8:")
for x in range (0, len(lstutf8)):
    print("byte_ele= ", lstutf8[x])


# Let's get a signature over all ascii elements
separator=" "
elesascii=separator.join(lstascii)
elesutf8= elesascii.encode("utf-8")

# Generation of a Pri/Pub key pair
# sender's Pri key 
privKey = SigningKey.generate() # Pri key, uses NIST192p
veriKey = priv_key.get_verifying_key() # The veri_key is the Pub key

sig_elesutf8= privKey.sign(elesutf8)

lstutf8.append(sig_elesutf8) #sent to reveiver


lstutf8_withsig= lstutf8 # careful: 
                         # append doesn't return a list
print("\nlstutf8 with signature included:")
for x in range (0, len(lstutf8_withsig)):
    print("ele= ", lstutf8_withsig[x])


##########The receiver's end############
"""
You can include the following line to make signature
verification fail
"""
# byteB= b"c_B"
#lstutf8_withsig[0]= byteB 


recv_lstutf8_withsig= lstutf8_withsig 

if len(recv_lstutf8_withsig) >= 1 :
   sig_retrieved= recv_lstutf8_withsig.pop()
   recv_lstutf8_withoutsig= recv_lstutf8_withsig 
else:
   raise Exception("Erroneous response from PBB")

recv_lst= map(bytes.decode, recv_lstutf8_withoutsig)
recv_lstascii= list(recv_lst)

print("\nrecv_lstascii:")
for x in range (0, len(recv_lstascii)):
    print("ele= ", recv_lstascii[x])

print("\nReceived signature= ", sig_retrieved)

sepa=" "

elems=sepa.join(recv_lstascii)

elemsutf8= elems.encode("utf-8")

print("\nReceiver uses veri_key to verify signature")
# This verification shows that the content
# 1) was signed by the entity holding the counter
#    part of veriKey, that is privKey. In this
#    for example, the sender of the list.
# 2) That the elements of the list have not
#    been altered.
if veriKey.verify(sig_retrieved, elemsutf8) == True:
   print("\nSignature verification of recv_lstutf8_withsig SUCCESSFUL")
else:
   raise Exception("Signature verification of recv_lstutf8_withsig, FAILED")
# assert vk.verify(signature, b"message")

