""" 
  Programmer: Carlos Molina
  Source: https://www.cryptoexamples.com/python_cryptography_string_signature_rsa.html 
  Date: 13 Sep 2019 
  Purpose: Example Code for Python based signing of a String 
           using SHA-512, RSA 4096, BASE64 and UTF-8 encoding 
   
  Execution on my MacBookAir: 
   1) I have bash-3.2$ python3 --version
          Python 3.7.4
   
   2) % pip install cryptography /* pip3 doesnt work
   
   3) bash-3.2$ python3 signmsg.py
       INFO:__main__:Signature: b'Cp216GoF9yY3p_tIVjMnUIphybdkOLRP4uaXPzp
       ...
       f7tJ4j4SNYz_pRsv75rq4n9wra50eaYCIXNkARN0bnF-0lC1ss='
       INFO:__main__:Signature is correct: True
   bash-3.2$ 

   The programs works fine, I made the verification fails in
   two manners: alteration of the signature and alteration
   of the original text.
"""

import base64
import logging

from cryptography.exceptions import InvalidSignature
from cryptography.exceptions import UnsupportedAlgorithm
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric import rsa

# set up logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def demonstrate_signature_rsa(plain_text):
    """
    Example for cryptographic signing of a string in one method.
    - Generation of public and private RSA 4096 bit keypair
    - SHA-512 with RSA signature of text using PSS and MGF1 padding
    - BASE64 encoding as representation for the byte-arrays
    - UTF-8 encoding of Strings
    - Exception handling
    """
    try:
        # GENERATE NEW KEYPAIR
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=4096,
            backend=default_backend()
        )
        public_key = private_key.public_key()

        # SIGN DATA/STRING
        signature = private_key.sign(
            data=plain_text.encode('utf-8'),
            padding=padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            algorithm=hashes.SHA256()

        )
        logger.info("Signature:\n %s", base64.urlsafe_b64encode(signature))


        # VERIFY JUST CREATED SIGNATURE USING PUBLIC KEY
        try:
            public_key.verify(
                #
                # Either or these alterations make verify to fail
                # signature=signature + bytes('some alteration', 'utf-8'),
                # data=plain_text.encode('utf-8') + '12345'.encode('utf-8'), 
                #
                signature=signature,
                data=plain_text.encode('utf-8'),
                padding=padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                algorithm=hashes.SHA256()
            )
            is_signature_correct = True
        except InvalidSignature:
            is_signature_correct = False

        logger.info("\n\nSignature is correct:  %s", is_signature_correct)
    except UnsupportedAlgorithm:
        logger.exception("Signing failed")


if __name__ == '__main__':
    # demonstrate method
    demonstrate_signature_rsa(
        "Text that should be signed to prevent unknown tampering with its content.")


