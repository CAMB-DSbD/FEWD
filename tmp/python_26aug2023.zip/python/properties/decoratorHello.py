#!/usr/bin/env python
"""
title           : decoratorHello.py
description     : basic decorator example. 
source          : http://www.saltycrane.com/blog/2010/03/simple-python-decorator-examples/ 
author          : Carlos Molina Jimenez
date            : 31 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3 decoratorHello.py <- I didnt understand it yet 
python_version  : Python 3.6.0   
====================================================
"""

"""
Decorator:
 A function that takes one argument (the function being decorated)
 Returns the same function or a function with a similar signature
"""
def identity(ob):
    return ob

@identity
def myfunc():
    print ("my function")

myfunc()
print (myfunc)



