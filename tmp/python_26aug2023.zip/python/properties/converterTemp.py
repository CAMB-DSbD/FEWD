#!/usr/bin/env python
"""
title           : converterTemp.py
description     : basic class, objects and property: it convertes from
                  C to F  
source          : https://www.programiz.com/python-programming/property 
author          : Carlos Molina Jimenez
date            : 30 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3 converterTemp.py 
python_version  : Python 3.6.0   
====================================================
"""


class Celsius:
    def __init__(self, temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32



man = Celsius()

man.temperature = 37

tC= man.temperature

print("Temperature in C is " + str(tC))

tF= man.to_fahrenheit()

print("Temperature in F is " + str(tF))


"""
On 30 Dec 2017 I executed it from the python prompt
One needs to respect the identation!!!

>>> class Celsius:
...    def __init__(self, temperature = 0):
...      self.temperature = temperature
...    def to_fahrenheit(self):
...      return (self.temperature * 1.8) + 32
... 
>>> man = Celsius()
>>> man.temperature = 37
>>> man.temperature
37
"""
