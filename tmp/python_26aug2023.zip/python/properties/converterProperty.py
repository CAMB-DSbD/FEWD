#!/usr/bin/env python
"""
title           : converterProperty.py
description     : basic class, objects, getter, setter, property: it convertes from
                  C to F  
source          : https://www.programiz.com/python-programming/property 
author          : Carlos Molina Jimenez
date            : 30 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3 converterProperty.py 
python_version  : Python 3.6.0   
====================================================
"""
class Celsius:
    def __init__(self, temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    def getTemp(self):
        print("Getting value")
        return self._temperature

    def setTemp(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        print("Setting value")
        self._temperature = value

    temperature = property(getTemp,setTemp)
    """
    property attaches some code (get_temperature and set_temperature) to 
    the member attribute accesses (temperature).
    Any code that retrieves the value of temperature will automatically 
    call getTemp() instead of a dictionary (__dict__) look-up. 
    Similarly, any code that assigns a value to temperature will automatically 
    call setTemp().
    """

man = Celsius(37)

tC= man.getTemp()
print("Temperature in C is " + str(tC))

tF= man.to_fahrenheit()
print("Temperature in F is " + str(tF))


"""
This test fails cos of the constraint that
setTemp imposes

man = Celsius(-300)

tC= man.getTemp()
print("Temperature in C is " + str(tC))

tF= man.to_fahrenheit()
print("Temperature in F is " + str(tF))
"""

