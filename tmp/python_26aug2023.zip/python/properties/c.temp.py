#!/usr/bin/env python
"""
title           : converterTemp.py
description     : basic class, objects, getter, setter, property: it convertes from
                  C to F  
source          : https://www.programiz.com/python-programming/property 
author          : Carlos Molina Jimenez
date            : 30 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3 converterTempGetSet.py 
python_version  : Python 3.6.0   
====================================================
"""

class Celsius:
    def __init__(self, temperature = 0):
        self.set_temperature(temperature)

    def to_fahrenheit(self):
        return (self.get_temperature() * 1.8) + 32

    # new update
    def get_temperature(self):
        return self._temperature

    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        self._temperature = value


man = Celsius(37)

print(man.get_temperature())

#man.temperature(-340) 
#print(man.get_temperature())


"""
On 30 Dec 2017 I executed it from the python prompt
One needs to respect the identation!!!

>>> class Celsius:
...    def __init__(self, temperature = 0):
...      self.temperature = temperature
...    def to_fahrenheit(self):
...      return (self.temperature * 1.8) + 32
... 
>>> man = Celsius()
>>> man.temperature = 37
>>> man.temperature
37
"""
