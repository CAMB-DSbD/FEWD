#!/usr/bin/env python
"""
title           : tracedecorator.py
description     : understanding decorators 
source          : Introduction to Python - UMBC
author          : Carlos Molina Jimenez
date            : 31 Dec 2016
version         : 1.0
usage           : 
notes           :
compile and run : % python3 tracedecorator.py 
python_version  : Python 3.6.0   
====================================================
"""
def trace(f):
  def new_f(*args,**kwargs):
     print 'Entering %s%s' % (f.__name__, args)
     result = f(*args, **kwargs)
     print 'Exiting %s%s with %s' % (f.__name__, args, result)
     return result
  return new_f

def upperCase (myfun):
   def newfun(*args):
      res= args[0] 
      return res.upper()
   return newfun 

"""
 prtString is decorated: upon call the control is given to
    the upperCase decorator who replaces the original code
    of ptrString. The new code does the same except that
    it return the input string in upper case.
"""
@upperCase
def prtString(instring):
   return instring

print("\nOutput from prtString " + prtString("simon") + "\n")


@trace
def sum(n, m):
    return n + m

sum(10,20)


"""
sum is decorated
"""
@trace
def sum(n, m):
    return n + m

sum(10,20)

"""
fact is decorated
"""
@trace
def fact(n): return 1 if n<2 else n * fact(n-1)

fact(4)


"""
add is not decorated
"""
#@trace
def add(p,q):
   return p + q

print(add(10,20))

