"""
https://docs.python.org/3/library/http.html
"""

#from http.server import HTTPServer, SimpleHTTPRequestHandler

import requests

res = requests.get("https://cam.ac.uk:443", verify= False)
print("\n\n Request to https://cam.ac.uk:443, verify= False is",res)


res = requests.get("https://cam.ac.uk:443", verify= True)
print("\n\n Request to https://cam.ac.uk:443, verify= True is",res)


res = requests.get("https://localhost:4443", verify= False)
print("\n\n Request to https://localhost:443, verify= False is", res)


res = requests.get("https://localhost:4443", verify= True)
print("\n\n Request to https://localhost:4443, verify= True is", res)




"""
https://community.ibm.com/community/user/ibmz-and-linuxone/blogs/sheng-jie-han/2021/06/03/how-to-fix-certificate-verify-failed-self-signed-c



"""
