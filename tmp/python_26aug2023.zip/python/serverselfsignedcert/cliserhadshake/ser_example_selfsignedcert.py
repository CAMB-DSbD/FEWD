"""

23 Aug 2023
Doesn't work

"""

from http.server import HTTPServer, SimpleHTTPRequestHandler
import ssl
from pathlib import Path

PORT= 4443

httpd = HTTPServer(("localhost", PORT), SimpleHTTPRequestHandler)

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)

#ssl_context.load_cert_chain(Path(__file__).parent / "./reso/server/ser_cert.pem")
#ssl_context.load_cert_chain("./reso/server/ser_cert.pem")

#ssl_context.load_cert_chain(certfile="./resources/server/server.intermediate.chain.pem",

ssl_context.load_cert_chain(certfile="./reso/server/ser_cert.pem", keyfile="./reso/server/ser_key.pem")

httpd.socket = ssl_context.wrap_socket(
    httpd.socket,
    server_side=True,
)

print(f"server serving on https://localhost:{PORT}")
httpd.serve_forever()
