"""
title           : serhttp_selfsignedcert.py
                : Demonstrates how to create a self-signed certificate
                : for an http server.  
                : The cert, private key and procedure to create them
                : are in the certkeys folder.
                : 
                : 
source          : https://gist.github.com/dergachev/7028596 
                : (Dragorn421)
                : 
author          : Carlos Molina Jimenez
date            : 23 Aug 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 sertttp_selfsignedcert.py 
                : 2) On browser: https://localhost:4443
                :    Accept the warning messages and the browser will
                :    retrieve the content of the folder.
python_version  :     
                :
"""


from http.server import HTTPServer, SimpleHTTPRequestHandler
import ssl
from pathlib import Path

PORT= 4443

httpd = HTTPServer(("localhost", PORT), SimpleHTTPRequestHandler)

#ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)  works fine!!
ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)

ssl_context.load_cert_chain(certfile="./reso/server/ser_cert.pem", keyfile="./reso/server/ser_key.pem")

httpd.socket = ssl_context.wrap_socket(
    httpd.socket,
    server_side=True,
)

print(f"server serving on https://localhost:{PORT}")
httpd.serve_forever()
