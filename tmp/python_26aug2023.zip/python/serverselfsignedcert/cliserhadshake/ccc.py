"""
https://www.geeksforgeeks.org/ssl-certificate-verification-python-requests/

"""
# import requests module
import requests

# Making a get request
#response = requests.get('https://github.com', verify ='/path / to / certfile')
response = requests.get("127.0.0.1:4443", verify ="/Users/carlosmolina/code/python/serverselfsignedcert/cliserhadshake/ser_cert.pem")

# print request object
print(response)


