"""

23 Aug 2023
Doesn't work

"""



import http.server
import ssl


from pathlib import Path
import select

import tqdm
import os

"""
LOCAL_HOST = 'localhost'
LOCAL_PORT = 8282
RESOURCE_DIRECTORY = Path(__file__).resolve().parent / 'reso' / 'server'
SERVER_CERT_CHAIN = RESOURCE_DIRECTORY / 'server.intermediate.chain.pem'
SERVER_KEY = RESOURCE_DIRECTORY / 'ser_key.pem'
"""




httpd = http.server.HTTPServer(('localhost', 4443), http.server.SimpleHTTPRequestHandler)

httpd.socket = ssl.wrap_socket(httpd.socket, certfile='./reso/server/ser_cert.pem', server_side=True, ssl_version=ssl.PROTOCOL_TLS)

httpd.serve_forever()
