"""

Programmer: Carlos.Molina@cl.cam.ac.uk
Date:       23 Aug 2023

source:  https://snyk.io/blog/implementing-tls-ssl-python/

Program: server_port4443.py opens a socket on a local
         computer and listens on port 4443.
         It has a self-signed certificate created by
         Carlos Molina.
         Upon request, it provides informtion
         about its cert.

Run:   1) py server_port4443.py 

       2) I tested it with the shell script
          ./checkcert_local_server.txt

  bash-3.2$ ./checkcert_local_server.txt
  depth=0 C = GB, ST = Cambridge, L = Cambridge, O = Cambridge University, OU = Computer Laboratory, CN = Computer Lab, emailAddress = carlos.molina@cl.cam.ac.uk
  verify error:num=18:self signed certificate
  verify return:1
  depth=0 C = GB, ST = Cambridge, L = Cambridge, O = Cambridge University, OU = Computer Laboratory, CN = Computer Lab, emailAddress = carlos.molina@cl.cam.ac.uk
  verify return:1
  DONE
  bash-3.2$ 



"""



from http.server import HTTPServer, SimpleHTTPRequestHandler
import ssl

PORT= 4443

httpd = HTTPServer(('localhost', PORT), 
                           SimpleHTTPRequestHandler)

httpd.socket = ssl.wrap_socket(httpd.socket,
  certfile='./ser.certificate.pem', keyfile='./ser.key.pem', server_side=True)

print("server waiting for client's requests on port ", PORT)
httpd.serve_forever()


