"""

https://snyk.io/blog/implementing-tls-ssl-python/


import http.server
import ssl

httpd = http.server.HTTPServer(('localhost', 4443),
        http.server.SimpleHTTPRequestHandler)
httpd.socket = ssl.wrap_socket (httpd.socket,
        certfile='./ser.certificate.pem', server_side=True, ssl_version=ssl.PROTOCOL_TLS)
httpd.serve_forever()

"""


from http.server import HTTPServer, SimpleHTTPRequestHandler
import ssl


httpd = HTTPServer(('localhost', 4443), 
                           SimpleHTTPRequestHandler)

httpd.socket = ssl.wrap_socket(httpd.socket,
  certfile='./ser.certificate.pem', keyfile='./ser.key.pem', server_side=True)

print("server waiting for client's requests... ")
httpd.serve_forever()
