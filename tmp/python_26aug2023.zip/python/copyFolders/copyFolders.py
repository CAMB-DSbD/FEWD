
"""
title           : mainprog.py
description     : Testing a prog for removing N subfolders from
                : a folder. 
                : I used this functions to generate N sequences
                : of contractual operations to be used as use
                : cases to tests the Contract Compliant Checker
                : 
source          :
author          : Carlos Molina-Jimenez
date            : 8 Jul 2018
version         : 1.0
usage           :
notes           :
compile and run : % python mainprog.py
python_version  : Python 2.7.12
====================================================
"""


def copySubFolders(src, dst):
    import shutil
    try:
        shutil.copytree(src, dst)
    # Directories are the same
    except shutil.Error as e:
        print('Directory not copied. Error: %s' % e)
    # Any error saying that the directory doesn't exist
    except OSError as e:
        print('Directory not copied. Error: %s' % e)

def create_sorted_folder_lst(folder_name):
    import os
    lst= os.listdir(folder_name) # returns list
    lst.sort() 
    return lst # return lst sorted alphabetically

def trim_folder_lst(lst, n):
    newlst = lst[n:]
    print (newlst)
    return newlst # return lst after removing first n elements
    
def rm_folders(sub_folders_lst):
    import shutil
    for sub_folder in sub_folders_lst:
        shutil.rmtree(sub_folder) # rm subfoldrs in lst

