"""
title           : mainprog.py
description     : Testing a prog for removing N subfolders from
                : a folder.
                : I used this functions to generate N sequences
                : of contractual operations to be used as use
                : cases to tests the Contract Compliant Checker
source          :  
author          : Carlos Molina-Jimenez
date            : 8 Jul 2018 
version         : 1.0
usage           : 
notes           :
compile and run : It assumes the existance of copyFolders.py
                : in the local folder and
                : of srcFolder.
                : It fails if dstFolder already exists.
                : 
                : % python mainprog.py  
python_version  : Python 2.7.12   
====================================================
"""
import copyFolders 
import os

copyFolders.copySubFolders("srcFolder", "dstFolder")

os.chdir("dstFolder")
print "In pn folfer now"


lst= copyFolders.create_sorted_folder_lst(".")
print ("\n There're  " + str(len(lst))) + " folders"
print (lst)

# To test, I remove from the list first element.
rm_folders_in_lst= copyFolders.trim_folder_lst(lst,1)

print ("\n Now " + str(len(rm_folders_in_lst))) + " folders\n" 

# To test, I all the elements left in the list 
copyFolders.rm_folders(rm_folders_in_lst)



