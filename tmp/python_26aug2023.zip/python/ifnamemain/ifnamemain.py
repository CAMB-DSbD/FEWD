
"""
title           : ifnamemain.py 
description     : just an example of class
source          : https://www.mygreatlearning.com/blog/python-main/ 
                : see also 
                : https://www.softwaretestinghelp.com/python/python-main-function/
author          : Carlos Molina Jimenez
date            : 1 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 ifnamemain.py 
python_version  :     
                :
"""

"""
print("How are you?")

def main():
          print("What about you?")

print("I am fine")

if __name__ == "__main__":
         main()

python3 ifnamemain.py
How are you?
I am fine
What about you?
"""

def how():
  print("How are you?")

def fine():
  print("I am fine")

def main():
          how()
          fine()
          print("What about you?")
        
if __name__ == "__main__":
         main()
         fine()

fine()

