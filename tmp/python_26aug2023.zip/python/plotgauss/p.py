#!/usr/bin/env python
#title           : gaussplot.py
#description     : This will create a a basic Guassian bell.
#source          : https://stackoverflow.com/questions/20011122/
#                : fitting-a-normal-distribution-to-1d-data  
#author          : Carlos Molina Jimenez
#date            : 5 Oct 2020
#version         : 1.0
#usage           : python gaussplot.py
#notes           : I have to  run % pip3 install scipy 
#                :
#python_version  : Python 3.6.0   
#
#compile and run : % python3 gauss.py 
#                  Shows the Gaussian curve                                          
#======================================================

import numpy as np 
from scipy.stats import norm
import matplotlib.pyplot as plt


# To generate a sequence of random variates, 
# use the size keyword argument. 
# https://docs.scipy.org/doc/scipy/reference/tutorial/stats.html
# size is the amout of continuous random variable (rvs)
# I experimented with size=1, size=5, etc.
data = norm.rvs(10.0, 2.5, size=12)


# Fit a normal distribution to the data:
# There is also expon.fit for exponential distribution
mu, std = norm.fit(data)

# Plot the histogram.
plt.hist(data, bins=25, density=True, alpha=0.6, color='g')

# Plot the PDF.
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
title = "Fit results: mu = %.2f,  std = %.2f" % (mu, std)
plt.title(title)

plt.show()

