#!/usr/bin/env python
#title           : pyscript.py
#description     : This will create a header for a python script.
#source          : https://www.learnpython.org/en/Hello,_World!
#author          : Carlos Molina Jimenez
#date            : 30 Dec 2016
#version         : 1.0
#usage           : python pyscript.py to show hello world
#notes           :
#compile and run : % python3 HelloWorld.py 
#python_version  : Python 3.6.0   
#====================================================

print("Goodbye, World!")
