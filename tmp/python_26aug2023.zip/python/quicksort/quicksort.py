from random import randint


random_list = []
# random_list = [12, 55, 65, 1, 12, 57, 8, 12, 10, 23, 20, 31]


for i in range(20):
    random_list.append(randint(1, 100))

inf = 0
sup = len(random_list) - 1


def partition(array, low, up):
    i = low + 1
    j = up
    pivot = array[low]
    while(i <= j):
        while(array[i] < pivot and i < up):
            i += 1
        while(array[j] > pivot):
            j -= 1
        if(i < j):
            array[i], array[j] = array[j], array[i]
            i += 1
            j -= 1
        else:
            i += 1
    array[low] = array[j]
    array[j] = pivot
    return j


def quick_sort(array, low, up):
    if(low >= up):
        return
    pivot_index = partition(array, low, up)
    quick_sort(array, low, pivot_index - 1)
    quick_sort(array, pivot_index + 1, up)


print("Lista sin ordenar")
print(random_list)

quick_sort(random_list, inf, sup)

print("Lista ordenada")
print(random_list)
