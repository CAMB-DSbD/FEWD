def quicksort_recursive(array):
    if len(array) == 0:
        return array
    p = len(array) // 2
    l = [i for i in array if i < array[p]]
    m = [i for i in array if i == array[p]]
    r = [i for i in array if i > array[p]]
    return quicksort_recursive(l) + m + quicksort_recursive(r)


test_list = [12, 24, 67, 34, 12, 4, 66, 23, 4, 52, 1, 12, 100, 3, 4, 52, 21]
print("Unordered list")
print(test_list, end="\n\n")
print("Ordered list after applying 'quicksort' algorithm")
print(quicksort_recursive(test_list))
