"""
title           : onlineargs.py 
description     : Demos of how to read online arguments 
                :
source          : https://www.geeksforgeeks.org/command-line-arguments-in-python/
                : 
author          : Carlos Molina Jimenez
date            : 7 Jul 2023
version         : 1.0
usage           : 
notes           :
compile and run : % python3 onlineags.py 9 5 4 10
python_version  :     
                :
"""


import sys
 
# total arguments
n = len(sys.argv)
print("Total arguments passed:", n)
 
# Arguments passed
print("\nThe name of the program is stored in sys.argv[1]. In this ex is:", sys.argv[0])
 
print("\nArguments passed:", end = " ")
for i in range(1, n):
    print(sys.argv[i], end = " ")
     
# Addition of numbers
Sum = 0
# Using argparse module
for i in range(1, n):
    Sum += int(sys.argv[i])
     
print("\n\nResult:", Sum)
